import { getNodeAtIndexFromEndOfDoublyLinkedList } from '../list/doubly-linked-list';

export interface IDoublyLinkedListNode<GValue> {
  previous: IDoublyLinkedListNode<GValue> | null;
  next: IDoublyLinkedListNode<GValue> | null;
  value: GValue;
}

export function createDoublyLinkedListNode<GValue>(
  value: GValue,
): IDoublyLinkedListNode<GValue> {
  return {
    previous: null,
    next: null,
    value,
  };
}


/** HELPERS **/

/**
 * Creates a link between two nodes: nodeA <-->>--> nodeB
 * [...A, nodeA, nodeB, ...B]
 * INFO: A.next and B.previous are not modified
 */
export function linkDoublyLinkedListNodes<GValue>(
  nodeA: IDoublyLinkedListNode<GValue>,
  nodeB: IDoublyLinkedListNode<GValue>,
): void {
  nodeA.next = nodeB;
  nodeB.previous = nodeA;
}

/**
 * Unlinks the previous of a node.
 * [...A, node, ...B] => [...A  -->, ...B]
 */
export function unlinkPreviousOfDoublyLinkedListNode<GValue>(
  node: IDoublyLinkedListNode<GValue>,
): void {
  if (node.previous !== null) {
    node.previous.next = node.next;
  }
}

/**
 * Unlinks the next of a node.
 * [...A, node, ...B] => [...A , <-- ...B]
 */
export function unlinkNextOfDoublyLinkedListNode<GValue>(
  node: IDoublyLinkedListNode<GValue>,
): void {
  if (node.next !== null) {
    node.next.previous = node.previous;
  }
}

/**
 * Unlinks a node.
 * [...A, node, ...B] => [...A, ...B]
 * INFO: node.previous and node.next are not modified
 */
export function unlinkDoublyLinkedListNode<GValue>(
  node: IDoublyLinkedListNode<GValue>,
): void {
  unlinkPreviousOfDoublyLinkedListNode<GValue>(node);
  unlinkNextOfDoublyLinkedListNode<GValue>(node);
}

/**
 * Changes node.previous and node.next to null
 */
export function isolateDoublyLinkedListNode<GValue>(
  node: IDoublyLinkedListNode<GValue>,
): void {
  node.previous = null;
  node.next = null;
}


/**
 * Detaches 'node' from it's list
 * [...A, node, ...B] => [...A, ...B] and 'node' detached
 */
export function detachDoublyLinkedListNode<GValue>(
  node: IDoublyLinkedListNode<GValue>,
): void {
  unlinkDoublyLinkedListNode<GValue>(node);
  isolateDoublyLinkedListNode<GValue>(node);
}



/**
 * Inserts 'node' before 'referenceNode'
 * [...A, referenceNode, ...B] => [...A, node, referenceNode,...B]
 * INFO: assumes node is unlinked
 */
export function insertUnlinkedDoublyLinkedListNodeBefore<GValue>(
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue>,
): void {
  if (referenceNode.previous !== null) {
    linkDoublyLinkedListNodes<GValue>(referenceNode.previous, node);
  }

  linkDoublyLinkedListNodes<GValue>(node, referenceNode);
}

/**
 * Inserts 'node' before 'referenceNode'
 * @see insertUnlinkedDoublyLinkedListNodeBefore
 */
export function insertDoublyLinkedListNodeBefore<GValue>(
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue>,
): void {
  unlinkDoublyLinkedListNode<GValue>(node);
  insertUnlinkedDoublyLinkedListNodeBefore<GValue>(node, referenceNode);
}

/**
 * Inserts 'node' after 'referenceNode'
 * [...A, referenceNode, ...B] => [...A, referenceNode, node,...B]
 * INFO: assumes node is unlinked
 */
export function insertUnlinkedDoublyLinkedListNodeAfter<GValue>(
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue>,
): void {
  if (referenceNode.next !== null) {
    linkDoublyLinkedListNodes<GValue>(node, referenceNode.next);
  }

  linkDoublyLinkedListNodes<GValue>(referenceNode, node);
}

/**
 * Inserts 'node' after 'referenceNode'
 * @see insertUnlinkedDoublyLinkedListNodeAfter
 */
export function insertDoublyLinkedListNodeAfter<GValue>(
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue>,
): void {
  unlinkDoublyLinkedListNode<GValue>(node);
  insertUnlinkedDoublyLinkedListNodeAfter<GValue>(node, referenceNode);
}



