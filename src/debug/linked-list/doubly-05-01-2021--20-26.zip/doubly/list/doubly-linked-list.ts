import {
  createDoublyLinkedListNode, IDoublyLinkedListNode, isolateDoublyLinkedListNode, linkDoublyLinkedListNodes,
  unlinkDoublyLinkedListNode
} from '../node/doubly-linked-list-node';


export interface IDoublyLinkedList<GValue> {
  first: IDoublyLinkedListNode<GValue> | null;
  last: IDoublyLinkedListNode<GValue> | null;
}

export function createDoublyLinkedList<GValue>(): IDoublyLinkedList<GValue> {
  return {
    first: null,
    last: null,
  };
}

// export class DoublyLinkedList<GValue> implements IDoublyLinkedList<GValue> {
//   first: IDoublyLinkedListNode<GValue> | null;
//   last: IDoublyLinkedListNode<GValue> | null;
//
//   constructor() {
//     this.first = null;
//     this.last = null;
//   }
// }


/** HELPERS **/

/**
 * Creates a DoublyLinkedList from a list of values
 */
export function createDoublyLinkedListFromValues<GValue>(
  values: Iterable<GValue>
): IDoublyLinkedList<GValue> {
  const list: IDoublyLinkedList<GValue> = createDoublyLinkedList<GValue>();
  const iterator: Iterator<GValue> = values[Symbol.iterator]();
  let result: IteratorResult<GValue>;
  while (!(result = iterator.next()).done) {
    appendValueForDoublyLinkedList<GValue>(list, result.value);
  }
  return list;
}


/* ASSIGN NODE TO LIST */

export const DOUBLY_LINKED_LIST_NODE_TO_LIST = new WeakMap<IDoublyLinkedListNode<any>, IDoublyLinkedList<any>>();

// INFO following functions assumes that each provided IDoublyLinkedListNode has been properly detached from any DOUBLY_LINKED_LIST_NODE_TO_LIST

/* MODIFY */

/* -- add --*/

/* - prepend - */

/**
 * Prepends 'node' into 'list'
 * [...list] => [node, ...list]
 * INFO: assumes node is unlinked
 * @returns 'node'
 */
export function prependNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
): IDoublyLinkedListNode<GValue> {
  if (list.first === null) { // empty list
    list.last = node;
    node.next = null;
  } else {
    linkDoublyLinkedListNodes<GValue>(node, list.first);
  }
  list.first = node;
  node.previous = null;
  return node;
}

/**
 * Prepends 'value' into 'list'
 * @see prependNodeForDoublyLinkedList
 */
export function prependValueForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  value: GValue,
): IDoublyLinkedListNode<GValue> {
  return prependNodeForDoublyLinkedList<GValue>(list, createDoublyLinkedListNode<GValue>(value));
}


/* - append - */

/**
 * Appends 'node' into 'list'
 * [...list] => [...list, node]
 * INFO: assumes node is unlinked
 * @returns 'node'
 */
export function appendUnlinkedNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
): IDoublyLinkedListNode<GValue> {
  if (list.last === null) { // empty list
    list.first = node;
    node.previous = null;
  } else {
    linkDoublyLinkedListNodes<GValue>(list.last, node);
  }
  list.last = node;
  node.next = null;
  return node;
}

/**
 * Appends 'node' into 'list'
 * @see appendUnlinkedNodeForDoublyLinkedList
 */
export function appendNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
): IDoublyLinkedListNode<GValue> {
  unlinkDoublyLinkedListNode<GValue>(node);
  return appendUnlinkedNodeForDoublyLinkedList<GValue>(list, node);
}


/**
 * Appends 'value' into 'list'
 * @see appendUnlinkedNodeForDoublyLinkedList
 */
export function appendValueForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  value: GValue,
): IDoublyLinkedListNode<GValue> {
  return appendUnlinkedNodeForDoublyLinkedList<GValue>(list, createDoublyLinkedListNode<GValue>(value));
}


/* - insert - */

/* - insert - before - */

/**
 * Inserts 'node' into 'list' before 'referenceNode'
 * [...listA, referenceNode, ...listB] => [...listA, node, referenceNode, ...listB]
 * INFO: assumes node is unlinked
 * INFO: assumes referenceNode is in the list
 * @returns 'node'
 */
export function insertUnlinkedNodeBeforeReferenceNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue>,
): IDoublyLinkedListNode<GValue> {
  if (referenceNode.previous === null) { // referenceNode is the first node of the list
    list.first = node;
    node.previous = null;
  } else {
    linkDoublyLinkedListNodes<GValue>(referenceNode.previous, node);
  }
  linkDoublyLinkedListNodes<GValue>(node, referenceNode);
  return node;
}

/**
 * Inserts 'node' into 'list' before 'referenceNode'
 * @see insertUnlinkedNodeBeforeReferenceNodeForDoublyLinkedList
 */
export function insertUnlinkedNodeBeforeOptionalReferenceNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue> | null,
): IDoublyLinkedListNode<GValue> {
  if (referenceNode === null) { // list is empty
    list.first = node;
    list.last = node;
    isolateDoublyLinkedListNode<GValue>(node);
    return node;
  } else {
    return insertUnlinkedNodeBeforeReferenceNodeForDoublyLinkedList<GValue>(list, node, referenceNode);
  }
}

/**
 * Inserts 'value' into 'list' before 'referenceNode'
 * @see insertUnlinkedNodeBeforeReferenceNodeForDoublyLinkedList
 * INFO: assumes referenceNode is in the list
 */
export function insertValueBeforeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  value: GValue,
  referenceNode: IDoublyLinkedListNode<GValue> | null,
): IDoublyLinkedListNode<GValue> {
  return insertUnlinkedNodeBeforeOptionalReferenceNodeForDoublyLinkedList<GValue>(
    list,
    createDoublyLinkedListNode<GValue>(value),
    referenceNode,
  );
}

/* - insert - after - */

/**
 * Inserts 'node' into 'list' after 'referenceNode'
 * [...listA, referenceNode, ...listB] => [...listA, referenceNode, node, ...listB]
 * INFO: assumes node is unlinked
 * INFO: assumes referenceNode is in the list
 * @returns 'node'
 */
export function insertUnlinkedNodeAfterReferenceNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue>,
): IDoublyLinkedListNode<GValue> {
  if (referenceNode.next === null) { // referenceNode is the last node of the list
    list.last = node;
    node.next = null;
  } else {
    linkDoublyLinkedListNodes<GValue>(node, referenceNode.next);
  }
  linkDoublyLinkedListNodes<GValue>(referenceNode, node);
  return node;
}

/**
 * Inserts 'node' into 'list' after 'referenceNode'
 * @see insertUnlinkedNodeAfterReferenceNodeForDoublyLinkedList
 */
export function insertUnlinkedNodeAfterOptionalReferenceNodeForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
  referenceNode: IDoublyLinkedListNode<GValue> | null,
): IDoublyLinkedListNode<GValue> {
  if (referenceNode === null) { // list is empty
    list.first = node;
    list.last = node;
    isolateDoublyLinkedListNode<GValue>(node);
    return node;
  } else {
    return insertUnlinkedNodeAfterReferenceNodeForDoublyLinkedList<GValue>(list, node, referenceNode);
  }
}

/**
 * Inserts 'value' into 'list' after 'referenceNode'
 * @see insertUnlinkedNodeAfterReferenceNodeForDoublyLinkedList
 * INFO: assumes referenceNode is in the list
 */
export function insertValueAfterForDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  value: GValue,
  referenceNode: IDoublyLinkedListNode<GValue> | null,
): IDoublyLinkedListNode<GValue> {
  return insertUnlinkedNodeAfterOptionalReferenceNodeForDoublyLinkedList<GValue>(
    list,
    createDoublyLinkedListNode<GValue>(value),
    referenceNode,
  );
}


/* -- remove --*/

/**
 * Detaches all nodes of 'list'
 */
export function makeDoublyLinkedListEmpty<GValue>(
  list: IDoublyLinkedList<GValue>,
): void {
  if (list.first !== null) {
    list.first.previous = null;
    list.first = null;
  }
  if (list.last !== null) {
    list.last.next = null;
    list.last = null;
  }
}

/* - first - */

/**
 * Removes and returns the first node of 'list'
 * [first, ...list] => [...list]
 * INFO: if the list is empty, returns null
 */
export function removeFirstNodeOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
): IDoublyLinkedListNode<GValue> | null {
  const node: IDoublyLinkedListNode<GValue> | null = list.first;
  if (node !== null) { // non empty list
    const next: IDoublyLinkedListNode<GValue> | null = node.next;
    isolateDoublyLinkedListNode<GValue>(node);
    if (next === null) { // uniq node
      list.last = null;
    } else {
      next.previous = null;
    }
    list.first = next;
  }
  return node;
}

/**
 * Removes and returns the first value of 'list'
 * @see removeFirstNodeOfDoublyLinkedList
 * INFO: if the list is empty, returns undefined
 */
export function removeFirstValueOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
): GValue | undefined {
  return getOptionalDoublyLinkedListNodeValue<GValue>(removeFirstNodeOfDoublyLinkedList<GValue>(list));
}

/* - last - */

/**
 * Removes and returns the last node of 'list'
 * [...list, last] => [...list]
 * INFO: if the list is empty, returns null
 */
export function removeLastNodeOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
): IDoublyLinkedListNode<GValue> | null {
  const node: IDoublyLinkedListNode<GValue> | null = list.last;
  if (node !== null) { // non empty list
    const previous: IDoublyLinkedListNode<GValue> | null = node.previous;
    isolateDoublyLinkedListNode<GValue>(node);
    if (previous === null) { // uniq node
      list.first = null;
    } else {
      previous.next = null;
    }
    list.last = previous;
  }
  return node;
}

/**
 * Removes and returns the last value of 'list'
 * @see removeLastNodeOfDoublyLinkedList
 * INFO: if the list is empty, returns undefined
 */
export function removeLastValueOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
): GValue | undefined {
  return getOptionalDoublyLinkedListNodeValue<GValue>(removeLastNodeOfDoublyLinkedList<GValue>(list));
}


/* - somewhere - */

// /**
//  * Inserts 'node' into 'list' before 'referenceNode'
//  * [...listA, referenceNode, ...listB] => [...listA, node, referenceNode, ...listB]
//  * INFO: assumes node is unlinked
//  * INFO: assumes referenceNode is in the list
//  * @returns 'node'
//  */
// export function insertUnlinkedNodeBeforeForDoublyLinkedList<GValue>(
//   list: IDoublyLinkedList<GValue>,
//   node: IDoublyLinkedListNode<GValue>,
//   referenceNode: IDoublyLinkedListNode<GValue>,
// ): IDoublyLinkedListNode<GValue> {
//   if (referenceNode.previous === null) { // referenceNode is the first node of the list
//     list.first = node;
//   } else {
//     linkDoublyLinkedListNodes<GValue>(referenceNode.previous, node);
//   }
//   linkDoublyLinkedListNodes<GValue>(node, referenceNode);
//   return node;
// }


/* EXPLORE */

/**
 * Returns the value of 'node' or undefined if 'node' is null
 */
export function getOptionalDoublyLinkedListNodeValue<GValue>(
  node: IDoublyLinkedListNode<GValue> | null,
): GValue | undefined {
  return (node === null)
    ? void 0
    : node.value;
}


/**
 * Returns the number of nodes inside 'list'
 */
export function getDoublyLinkedListSize<GValue>(
  list: IDoublyLinkedList<GValue>,
): number {
  let size: number = 0;
  let node: IDoublyLinkedListNode<GValue> | null = list.first;
  while (node !== null) {
    size++;
    node = node.next;
  }
  return size;
}


/**
 * Returns true if 'list' has 'node'
 */
export function doublyLinkedListIncludesNode<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
): boolean {
  let _node: IDoublyLinkedListNode<GValue> | null = list.first;
  while (_node !== null) {
    if (_node === node) {
      return true;
    }
    _node = _node.next;
  }
  return false;
}


/* -- index -- */

/* - from start - */

/**
 * Returns the node at 'index' from the start of 'list'
 */
export function getNodeAtIndexFromStartOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
): IDoublyLinkedListNode<GValue> | null {
  let node: IDoublyLinkedListNode<GValue> | null = list.first;
  let _index: number = 0;
  while ((node !== null) && (_index < index)) {
    _index++;
    node = node.next;
  }
  return node;
}

/**
 * Returns the value at 'index' from the start of 'list'
 * INFO: if index is out of range, throws a RangeError
 */
export function getValueAtIndexFromStartOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
): GValue {
  const node: IDoublyLinkedListNode<GValue> | null = getNodeAtIndexFromStartOfDoublyLinkedList<GValue>(list, index);
  if (node === null) {
    throw new RangeError(`Index out of range`);
  } else {
    return node.value;
  }
}

/**
 * Returns the value at 'index' from the start of 'list'.
 * INFO: if index is out of range, returns undefined
 */
export function getOptionalValueAtIndexFromStartOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
): GValue | undefined {
  return getOptionalDoublyLinkedListNodeValue<GValue>(getNodeAtIndexFromStartOfDoublyLinkedList<GValue>(list, index));
}


/**
 * Sets the value at 'index' from the start of 'list'
 */
export function setValueAtIndexFromStartOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
  value: GValue,
): void {
  const node: IDoublyLinkedListNode<GValue> | null = getNodeAtIndexFromStartOfDoublyLinkedList<GValue>(list, index);
  if (node === null) {
    throw new RangeError(`Index out of range`);
  } else {
    node.value = value;
  }
}

/**
 * Returns the index of 'node' inside 'list' from start
 * INFO: returns -1 if node is not in the list
 */
export function indexOfNodeFromStartInDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
): number {
  let index: number = 0;
  let _node: IDoublyLinkedListNode<GValue> | null = list.first;
  while (_node !== null) {
    index++;
    if (_node === node) {
      return index;
    }
    _node = _node.next;
  }
  return -1;
}


/* - from end - */

/**
 * Returns the node at 'index' from the end of 'list'
 */
export function getNodeAtIndexFromEndOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
): IDoublyLinkedListNode<GValue> | null {
  let node: IDoublyLinkedListNode<GValue> | null = list.last;
  let _index: number = 0;
  while ((node !== null) && (_index < index)) {
    _index++;
    node = node.previous;
  }
  return node;
}

/**
 * Returns the value at 'index' from the end of 'list'
 */
export function getValueAtIndexFromEndOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
): GValue | undefined {
  return getOptionalDoublyLinkedListNodeValue<GValue>(getNodeAtIndexFromEndOfDoublyLinkedList<GValue>(list, index));
}


/**
 * Sets the value at 'index' from the end of 'list'
 */
export function setValueAtIndexFromEndOfDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  index: number,
  value: GValue,
): void {
  const node: IDoublyLinkedListNode<GValue> | null = getNodeAtIndexFromEndOfDoublyLinkedList<GValue>(list, index);
  if (node === null) {
    throw new RangeError(`Index out of range`);
  } else {
    node.value = value;
  }
}


/**
 * Returns the index of 'node' inside 'list' from end
 * INFO: returns -1 if node is not in the list
 */
export function indexOfNodeFromEndInDoublyLinkedList<GValue>(
  list: IDoublyLinkedList<GValue>,
  node: IDoublyLinkedListNode<GValue>,
): number {
  let index: number = 0;
  let _node: IDoublyLinkedListNode<GValue> | null = list.last;
  while (_node !== null) {
    index++;
    if (_node === node) {
      return index;
    }
    _node = _node.previous;
  }
  return -1;
}


/* -- iterators-- */

/* - first to last - */

/**
 * Creates an iterator over the nodes of a DoublyLinkedList (from first to last)
 */
export function * createDoublyLinkedListFirstToLastNodeIterator<GValue>(
  list: IDoublyLinkedList<GValue>,
): Generator<IDoublyLinkedListNode<GValue>> {
  let node: IDoublyLinkedListNode<GValue> | null = list.first;
  while (node !== null) {
    yield node;
    node = node.next;
  }
}

/**
 * Creates an iterator over the values of a DoublyLinkedList (from first to last)
 */
export function * createDoublyLinkedListFirstToLastValueIterator<GValue>(
  list: IDoublyLinkedList<GValue>,
): Generator<GValue> {
  const iterator: Iterator<IDoublyLinkedListNode<GValue>> = createDoublyLinkedListFirstToLastNodeIterator<GValue>(list);
  let result: IteratorResult<IDoublyLinkedListNode<GValue>>;
  while (!(result = iterator.next()).done) {
    yield result.value.value;
  }
}


/* - last to first - */

/**
 * Creates an iterator over the nodes of a DoublyLinkedList (from last to first)
 */
export function * createDoublyLinkedListLastToFirstNodeIterator<GValue>(
  list: IDoublyLinkedList<GValue>,
): Generator<IDoublyLinkedListNode<GValue>> {
  let node: IDoublyLinkedListNode<GValue> | null = list.last;
  while (node !== null) {
    yield node;
    node = node.previous;
  }
}


/**
 * Creates an iterator over the values of a DoublyLinkedList (from last to first)
 */
export function * createDoublyLinkedListLastToFirstValueIterator<GValue>(
  list: IDoublyLinkedList<GValue>,
): Generator<GValue> {
  const iterator: Iterator<IDoublyLinkedListNode<GValue>> = createDoublyLinkedListLastToFirstNodeIterator<GValue>(list);
  let result: IteratorResult<IDoublyLinkedListNode<GValue>>;
  while (!(result = iterator.next()).done) {
    yield result.value.value;
  }
}


