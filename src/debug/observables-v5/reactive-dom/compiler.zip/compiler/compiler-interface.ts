export type ILines = string[];

export interface IInjectLines {
  (lines: ILines): ILines;
}

export type ICompilerReturn = ILines | IInjectLines | null;

