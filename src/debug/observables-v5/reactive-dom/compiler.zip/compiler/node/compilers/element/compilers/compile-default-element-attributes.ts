import { ICompilerReturn, ILines } from '../../../../compiler-interface';
import { mergeCompilerReturnWithLines, nullIfEmptyLines } from '../../../../snipets';
import { compileAttribute } from './attribute/compile-attribute';
import { IAttributeCompiler } from './attribute/attribute-compiler-interface';

export function compileDefaultElementAttributes(
  node: Element,
  lines: ILines = [],
  compiler: IAttributeCompiler = compileAttribute,
): ILines | null {
  for (let i = 0, l = node.attributes.length; i < l; i++) {
    lines = mergeCompilerReturnWithLines(compiler(node.attributes.item(i) as Attr), lines);
  }
  return nullIfEmptyLines(lines);
}
