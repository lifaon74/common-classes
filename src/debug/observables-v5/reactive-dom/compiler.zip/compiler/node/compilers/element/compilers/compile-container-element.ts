import { ILines } from '../../../../compiler-interface';
import { optionalLines, scopeLines } from '../../../../snipets';
import { compileDefaultElementChildren } from './compile-default-element-children';


export function compileContainerElement(
  node: Element,
): ILines | null {
  return null;
  // if (node.tagName.toLowerCase() === 'container') {
  //   return [
  //     `// container`,
  //     `const node = new ContainerNode();`,
  //     ...optionalLines(compileDefaultElementChildren(node), (lines: ILines) => {
  //       return scopeLines([
  //         `// child nodes`,
  //         `const parentNode = node;`,
  //         ...lines,
  //       ]);
  //     }),
  //     `attachNode(node, parentNode);`
  //   ];
  // } else {
  //   return null;
  // }
}
