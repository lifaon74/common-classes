import { ICompilerReturn, ILines } from '../../../../compiler-interface';
import { compileNode } from '../../../compile-node';
import { isInjectLines, isLines, nullIfEmptyLines, scopeLines } from '../../../../snipets';
import { INodeCompiler } from '../../../node-compiler-interface';

export function compileDefaultElementChildren(
  node: Element,
  lines: ILines = [],
  compiler: INodeCompiler = compileNode,
): ILines | null {
  let childNode: Node | null = node.firstChild;
  while (childNode !== null) {
    const result: ICompilerReturn = compiler(childNode);
    if (isLines(result)) {
      lines.push(...scopeLines(result));
    } else if (isInjectLines(result)) {
      lines = result(lines);
    }
    childNode = childNode.nextSibling;
  }
  return nullIfEmptyLines(lines);
}
