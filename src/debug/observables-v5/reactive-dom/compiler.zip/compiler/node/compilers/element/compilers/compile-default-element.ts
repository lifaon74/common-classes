import { ILines } from '../../../../compiler-interface';
import { compileDefaultElementChildren } from './compile-default-element-children';
import { nullIfEmptyLines, scopeLines } from '../../../../snipets';
import { compileDefaultElementAttributes } from './compile-default-element-attributes';

export function compileDefaultElement(
  node: Element,
): ILines | null {
  const name: string = node.tagName.toLowerCase();
  let lines: ILines = [
    `// element '${ name }'`,
    `const node = createElement(${ JSON.stringify(name) });`,
    `attachNode(node, parentNode);`
  ];

  lines = compileDefaultElementAttributes(node, lines) || [];

  // {
  //   const result: ILines | null = compileDefaultElementChildren(node, lines);
  //   if (result !== null) {
  //     lines.push(...scopeLines([
  //       `// child nodes`,
  //       `const parentNode = node;`,
  //       ...result,
  //     ]));
  //   }
  // }


  return nullIfEmptyLines(lines);
  // return [
  //   `// element '${ name }'`,
  //   `const node = createElement(${ JSON.stringify(name) });`,
  //   ...optionalLines(compileDefaultElementAttributes(node)),
  //   ...optionalLines(compileDefaultElementChildren(node), (lines: ILines) => {
  //     return scopeLines([
  //       `// child nodes`,
  //       `const parentNode = node;`,
  //       ...lines,
  //     ]);
  //   }),
  //   `attachNode(node, parentNode);`
  // ];
}
