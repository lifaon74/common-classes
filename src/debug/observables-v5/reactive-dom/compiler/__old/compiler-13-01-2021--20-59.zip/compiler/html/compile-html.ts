import { ICompilerReturn } from '../compiler-interface';
import { createElement } from '../../nodes/element/create-element';
import { compileNodes } from '../nodes/compile-nodes';


export function compileHTML(
  html: string,
): ICompilerReturn {
  const container: HTMLElement = createElement('div');
  container.innerHTML = html;
  return compileNodes(Array.from(container.childNodes));
}
