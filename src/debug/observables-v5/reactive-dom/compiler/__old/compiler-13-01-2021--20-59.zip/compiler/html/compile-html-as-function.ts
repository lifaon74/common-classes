import { INodeCompiler } from '../node/node-compiler-interface';
import { indentLines, optionalLines } from '../snipets';
import { attachNode } from '../../dom-mutation/node/attach-node';
import { detachNode } from '../../dom-mutation/node/detach-node';
import { createDocumentFragment } from '../../nodes/create-document-fragment';
import { createStaticTextNode } from '../../nodes/text/create-static-text-node';
import { createReactiveTextNode } from '../../nodes/text/create-reactive-text-node';
import { createElement } from '../../nodes/element/create-element';
import { setStaticAttribute } from '../../nodes/element/attribute/set-static-attribute';
import { setReactiveProperty } from '../../nodes/element/property/set-reactive-property';
import { setReactiveAttribute } from '../../nodes/element/attribute/set-reactive-attribute';
import { setReactiveClass } from '../../nodes/element/class/set-reactive-class';
import { setReactiveClassList } from '../../nodes/element/class/set-reactive-class-list';
import { setReactiveStyle } from '../../nodes/element/style/set-reactive-style';
import { setReactiveStyleList } from '../../nodes/element/style/set-reactive-style-list';
import { ContainerNode } from '../../nodes/container-node';
import { compileHTML } from './compile-html';
import { setReactiveEventListener } from '../../nodes/element/event-listener/set-reactive-event-listener';
import { ILines } from '../compiler-interface';

export const DEFAULT_CONSTANTS_TO_IMPORT = {
  attachNode,
  detachNode,
  createDocumentFragment,
  createStaticTextNode,
  createReactiveTextNode,
  createElement,
  setStaticAttribute,
  setReactiveProperty,
  setReactiveAttribute,
  setReactiveClass,
  setReactiveClassList,
  setReactiveStyle,
  setReactiveStyleList,
  setReactiveEventListener,
  ContainerNode,
};
export const DEFAULT_CONSTANTS_TO_IMPORT_SET = new Set<string>([
  'attachNode',
  'detachNode',
  'createDocumentFragment',
  'createStaticTextNode',
  'createReactiveTextNode',
  'createElement',
  'setStaticAttribute',
  'setReactiveProperty',
  'setReactiveAttribute',
  'setReactiveClass',
  'setReactiveClassList',
  'setReactiveStyle',
  'setReactiveStyleList',
  'setReactiveEventListener',
  'ContainerNode',
]);

export function compileHTMLAsFunction(
  html: string,
  constantsToImport: Set<string> = DEFAULT_CONSTANTS_TO_IMPORT_SET,
  compiler?: INodeCompiler,
): ILines {
  return [
    `({`,
    ...indentLines(Array.from(constantsToImport).map((name: string) => `${ name },`)),
    `}) => {`,
    ...indentLines([
      `const parentNode = createDocumentFragment();`,
      ...optionalLines(compileHTML(html)),
      `return parentNode;`,
    ]),
    `}`,
  ];
}

export interface ICompiledHTMLFunction<GConstants extends object> {
  (constantsToImport: GConstants): DocumentFragment;
}

export function compileHTMLAsEvaluatedFunction<GConstants extends object>(
  html: string,
  constantsToImport?: Set<string>,
  compiler?: INodeCompiler,
): ICompiledHTMLFunction<GConstants> {
  return new Function(
    'constantsToImport',
    'return (' + compileHTMLAsFunction(html, constantsToImport, compiler).join('\n') + ')(constantsToImport);'
  ) as ICompiledHTMLFunction<GConstants>;
}
