import {
  compileHTMLAsEvaluatedFunction, DEFAULT_CONSTANTS_TO_IMPORT, ICompiledHTMLFunction
} from './compile-html-as-function';
import { attachNodeWithEventAndCheck } from '../../light-dom/node/move/node/with-event/attach-node-with-event';

export interface ITemplateInjector<GData> {
  (container: Element, data: GData): void;
}

export function compileTemplateAsInjector<GData>(
  html: string,
  constantsToImport: object = DEFAULT_CONSTANTS_TO_IMPORT,
): ITemplateInjector<GData> {

  const createTemplate: ICompiledHTMLFunction<object> = compileHTMLAsEvaluatedFunction(html, new Set([
    ...Object.keys(constantsToImport),
    'data',
  ]));

  return (container: Element, data: GData): void => {
    attachNodeWithEventAndCheck(
      createTemplate({
        ...constantsToImport,
        data,
      }),
      container,
    );
  };
}

