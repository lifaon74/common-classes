import { ILines } from './compiler-interface';
import { createElement } from '../nodes/element/create-element';
import { INodeCompiler } from './node/node-compiler-interface';
import { compileDefaultElementChildren } from './node/compilers/element/compilers/compile-default-element-children';


export function compileHTML(
  html: string,
  compiler?: INodeCompiler,
): ILines | null {
  const container: HTMLElement = createElement('div');
  container.innerHTML = html;
  return compileDefaultElementChildren(container, compiler);
}
