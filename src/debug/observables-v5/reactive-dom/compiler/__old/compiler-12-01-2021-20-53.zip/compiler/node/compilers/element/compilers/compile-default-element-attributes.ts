import { ICompilerReturn, ILines } from '../../../../compiler-interface';
import { nullIfEmptyLines } from '../../../../snipets';
import { compileAttribute } from './attribute/compile-attribute';
import { IAttributeCompiler } from './attribute/attribute-compiler-interface';

export function compileDefaultElementAttributes(
  node: Element,
  compiler: IAttributeCompiler = compileAttribute,
): ILines | null {
  const lines: ILines = [];
  for (let i = 0, l = node.attributes.length; i < l; i++) {
    const result: ICompilerReturn = compiler(node.attributes.item(i) as Attr);
    if (result !== null) {
      lines.push(...result);
    }
  }
  return nullIfEmptyLines(lines);
}

export function compileDefaultElementAttributesFromParent(
  node: Element,
  compiler?: IAttributeCompiler,
): ILines | null {
  const result: ILines | null = compileDefaultElementAttributes(node, compiler);
  return (result === null)
    ? null
    : [
      `// attributes`,
      ...result,
    ];
}
