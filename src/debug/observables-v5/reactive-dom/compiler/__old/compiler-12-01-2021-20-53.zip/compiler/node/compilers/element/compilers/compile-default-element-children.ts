import { ICompilerReturn, ILines } from '../../../../compiler-interface';
import { compileNode } from '../../../compile-node';
import { nullIfEmptyLines, optionalLines, scopeLines } from '../../../../snipets';
import { INodeCompiler } from '../../../node-compiler-interface';

export function compileDefaultElementChildren(
  node: Element,
  compiler: INodeCompiler = compileNode,
): ILines | null {
  const lines: ILines = [];
  let childNode: Node | null = node.firstChild;
  while (childNode !== null) {
    const result: ICompilerReturn = compiler(childNode);
    if (result !== null) {
      lines.push(...result);
    }
    childNode = childNode.nextSibling;
  }
  return nullIfEmptyLines(lines);
}


export function compileDefaultElementChildrenFromParent(
  node: Element,
  compiler?: INodeCompiler,
): ILines | null {
  const result: ILines | null = compileDefaultElementChildren(node, compiler);
  return (result === null)
    ? null
    : scopeLines([
      `// child nodes`,
      `const parentNode = node;`,
      ...result,
    ]);
}
