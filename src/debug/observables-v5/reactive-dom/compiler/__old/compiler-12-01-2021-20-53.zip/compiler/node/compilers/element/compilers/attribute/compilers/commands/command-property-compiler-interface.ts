import { ICompilerReturn } from '../../../../../../../compiler-interface';

export interface ICommandPropertyCompiler {
  (name: string, value: string, prefixMode: boolean): ICompilerReturn;
}
