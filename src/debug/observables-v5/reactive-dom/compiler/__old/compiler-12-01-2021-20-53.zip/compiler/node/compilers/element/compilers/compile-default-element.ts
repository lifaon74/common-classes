import { ILines } from '../../../../compiler-interface';
import { compileDefaultElementChildrenFromParent } from './compile-default-element-children';
import { optionalLines, scopeLines } from '../../../../snipets';
import { compileDefaultElementAttributesFromParent } from './compile-default-element-attributes';

export function compileDefaultElement(
  node: Element,
): ILines | null {
  const name: string = node.tagName.toLowerCase();
  return scopeLines([
    `// element '${ name }'`,
    `const node = createElement(${ JSON.stringify(name) });`,
    `attachNode(node, parentNode);`,
    ...optionalLines(compileDefaultElementAttributesFromParent(node)),
    ...optionalLines(compileDefaultElementChildrenFromParent(node)),
  ]);
}
