import { Trait } from '@lifaon/traits';
import { TGenericTransformLike } from '../../transform/transform-types';

@Trait()
export abstract class TraitPipeThroughGetTransform<GSelf, GTransform extends TGenericTransformLike> {
  abstract getTransform(this: GSelf): GTransform;
}

