import { IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT, } from '../pipe-through-struct';
import { Impl } from '@lifaon/traits';
import { TGenericObservableLike } from '../../../observable/observable-types';
import { TPipeThroughLikeGTransformConstraint } from '../../pipe-through-types';
import { TraitPipeThroughGetTransform } from '../../traits/trait-pipe-through-get-transform';

@Impl()
export class ImplTraitGetTransformForPipeThroughStruct<GSelf extends IPipeThroughStruct<GObservable, GTransform>,
  GObservable extends TGenericObservableLike,
  GTransform extends TPipeThroughLikeGTransformConstraint<GObservable>> extends TraitPipeThroughGetTransform<GSelf, GTransform> {
  getTransform(this: GSelf): GTransform {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].transform;
  }
}
