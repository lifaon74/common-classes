import { IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT, } from '../pipe-through-struct';
import { TraitPipeThroughGetObservable } from '../../traits/trait-pipe-through-get-observable';
import { Impl } from '@lifaon/traits';
import { TGenericObservableLike } from '../../../observable/observable-types';
import { TPipeThroughLikeGTransformConstraint } from '../../pipe-through-types';

@Impl()
export class ImplTraitGetObservableForPipeThroughStruct<GSelf extends IPipeThroughStruct<GObservable, TPipeThroughLikeGTransformConstraint<GObservable>>, GObservable extends TGenericObservableLike> extends TraitPipeThroughGetObservable<GSelf, GObservable> {
  getObservable(this: GSelf): GObservable {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].observable;
  }
}
