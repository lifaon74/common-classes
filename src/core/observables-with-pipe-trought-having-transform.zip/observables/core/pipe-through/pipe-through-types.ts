import { TGenericObservableLike, TInferObservableLikeGObserver } from '../observable/observable-types';
import { IActivableLike, IsActivableLike } from '../../../activable/activable-types';
import { TraitPipeThroughGetObservable } from './traits/trait-pipe-through-get-observable';
import { ITransformLike } from '../transform/transform-types';
import { TraitIsImplementedBy } from '@lifaon/traits';
import { TraitPipeThroughGetTransform } from './traits/trait-pipe-through-get-transform';
import { TGenericObservableLikeWithEventListenerOn } from './struct/implementations/pipe-through-struct-activate-implementation';
import { TGenericObserverLike } from '../observer/observer-types';

export type TPipeThroughLikeGTransformConstraint<GObservable extends TGenericObservableLike> = ITransformLike<TInferObservableLikeGObserver<GObservable>, TGenericObservableLikeWithEventListenerOn>;


export interface IPipeThroughLike<GObservable extends TGenericObservableLike, GTransform extends TPipeThroughLikeGTransformConstraint<GObservable>> extends
  // activable traits
  IActivableLike<IPipeThroughLike<GObservable, GTransform>>,
  // own traits
  TraitPipeThroughGetObservable<any, GObservable>,
  TraitPipeThroughGetTransform<any, GTransform>
  //
{
}

export type TGenericTransformLikeWithGenericObservableLikeWithEventListenerOn = ITransformLike<TGenericObserverLike, TGenericObservableLikeWithEventListenerOn>;
export type TGenericPipeThroughLike = IPipeThroughLike<TGenericObservableLike, TGenericTransformLikeWithGenericObservableLikeWithEventListenerOn>;

export function IsPipeThroughLike<GObservable extends TGenericObservableLike, GTransform extends TPipeThroughLikeGTransformConstraint<GObservable>>(value: any): value is IPipeThroughLike<GObservable, GTransform> {
  return TraitIsImplementedBy(TraitPipeThroughGetObservable, value)
    && TraitIsImplementedBy(TraitPipeThroughGetTransform, value)
    && IsActivableLike(value);
}

/** TYPES **/

// export type TPipeThroughLikeGTransformConstraintWithEventListenerOn<GObservable extends TGenericObservableLike> = ITransformLike<TInferObservableLikeGObserver<GObservable>, TGenericObservableLikeWithEventListenerOn>;
