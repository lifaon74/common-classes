import { Trait, TraitEmit } from '@lifaon/traits';

@Trait()
export abstract class TraitObserverEmit<GSelf, GValue> extends TraitEmit<GSelf, GValue, void> {
}

export type TGenericTraitObserverEmit = TraitObserverEmit<any, any>;

// export type TInferTraitObserverEmitGValue<GTrait extends TGenericTraitObserverEmit> =
//   GTrait extends TraitObserverEmit<any, infer GValue>
//     ? GValue
//     : never;
