// import { TraitObservableRemoveObserver } from '../../../traits/trait-observable-remove-observer';
// import {
//   OBSERVABLE_PRIVATE_CONTEXT, TGenericObservableStruct, TInferObservableStructGObserver
// } from '../../observable-struct';
// import { TGenericObserverLike } from '../../../../observer/observer-types';
// import { Impl, TraitEventListenerDispatch } from '@lifaon/traits';
// import { TGenericObservableKeyValueTupleUnion } from '../../../observable-types';
//
// export interface IImplTraitRemoveObserverForObservableStructGSelfConstraint extends TGenericObservableStruct,
//   TraitEventListenerDispatch<any, TGenericObservableKeyValueTupleUnion> {
// }
//
// @Impl()
// export class ImplTraitRemoveObserverForObservableStruct<GSelf extends IImplTraitRemoveObserverForObservableStructGSelfConstraint> extends TraitObservableRemoveObserver<GSelf, TInferObservableStructGObserver<GSelf>> {
//   removeObserver(this: GSelf, observer: TInferObservableStructGObserver<GSelf>): GSelf {
//     type GObserver = TInferObservableStructGObserver<GSelf>;
//     const observers: TGenericObserverLike[] = this[OBSERVABLE_PRIVATE_CONTEXT].observers;
//     const index: number = observers.indexOf(observer);
//     if (index === -1) {
//       throw new Error(`Doesn't contain this Observer`);
//     } else {
//       observers.splice(index, 1);
//       this.dispatch('remove-observer', observer);
//       if (observers.length === 0) {
//         this.dispatch('inactive', void 0);
//       }
//     }
//     return this;
//   }
// }
