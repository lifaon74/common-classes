// import {
//   OBSERVABLE_PRIVATE_CONTEXT, TGenericObservableStruct, TInferObservableStructGObserver
// } from '../../observable-struct';
// import { TraitObservableAddObserver } from '../../../traits/trait-observable-add-observer';
// import { IsObserverLike, TGenericObserverLike } from '../../../../observer/observer-types';
// import { Impl, TraitEventListenerDispatch } from '@lifaon/traits';
// import { TGenericObservableKeyValueTupleUnion } from '../../../observable-types';
//
//
// export interface IImplTraitAddObserverUsingDispatchForObservableStructGSelfConstraint extends TGenericObservableStruct,
//   TraitEventListenerDispatch<any, TGenericObservableKeyValueTupleUnion> {
// }
//
// @Impl()
// export class ImplTraitAddObserverUsingDispatchForObservableStruct<GSelf extends IImplTraitAddObserverUsingDispatchForObservableStructGSelfConstraint> extends TraitObservableAddObserver<GSelf, TInferObservableStructGObserver<GSelf>> {
//   addObserver(this: GSelf, observer: TInferObservableStructGObserver<GSelf>): GSelf {
//     if (IsObserverLike(observer)) {
//       const observers: TGenericObserverLike[] = this[OBSERVABLE_PRIVATE_CONTEXT].observers;
//       if (observers.includes(observer)) {
//         observers.push(observer);
//         this.dispatch('add-observer', observer);
//         if (observers.length === 1) {
//           this.dispatch('active', void 0);
//         }
//       }
//       return this;
//     } else {
//       throw new TypeError(`Not an Observer`);
//     }
//   }
// }
