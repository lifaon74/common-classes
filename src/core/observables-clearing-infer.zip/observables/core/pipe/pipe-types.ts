import { IObservableLike } from '../observable/observable-types';
import { IActivableLike, IsActivableLike } from '../../../activable/activable-types';
import { TInferTraitPipeGetObservableGValue, TraitPipeGetObservable } from './traits/trait-pipe-get-observable';
import { TInferTraitPipeGetObserverGValue, TraitPipeGetObserver } from './traits/trait-pipe-get-observer';
import { TraitIsImplementedBy } from '@lifaon/traits';
import { TGenericObserverLike } from '../observer/observer-types';

export interface IPipeLike<GObservable extends IObservableLike<GObserver>, GObserver extends TGenericObserverLike> extends
  // activable traits
  IActivableLike<IPipeLike<GObservable, GObserver>>,
  // own traits
  TraitPipeGetObservable<any, GObservable>,
  TraitPipeGetObserver<any, GObserver>
  //
{
}

export type TGenericPipeLike = IPipeLike<any, any>;

export type TInferPipeLikeGObservable<GPipeLike extends TGenericPipeLike> = TInferTraitPipeGetObservableGValue<GPipeLike>;
export type TInferPipeLikeGObserver<GPipeLike extends TGenericPipeLike> = TInferTraitPipeGetObserverGValue<GPipeLike>;

export function IsPipeLike<GObservable extends IObservableLike<GObserver>, GObserver extends TGenericObserverLike>(value: any): value is IPipeLike<GObservable, GObserver> {
  return TraitIsImplementedBy(TraitPipeGetObservable, value)
    && TraitIsImplementedBy(TraitPipeGetObserver, value)
    && IsActivableLike(value);
}
