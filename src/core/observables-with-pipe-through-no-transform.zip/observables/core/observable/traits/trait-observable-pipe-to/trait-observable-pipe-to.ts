import { TGenericObservableLike, TInferObservableLikeGObserver } from '../../observable-types';
import { TInferObserverLikeGValue, TObserverEmitFunction } from '../../../observer/observer-types';
import { IPipeLike } from '../../../pipe/pipe-types';
import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitObservablePipeTo<GSelf extends TGenericObservableLike> {
  abstract pipeTo<GCallback extends TObserverEmitFunction<TInferObserverLikeGValue<TInferObservableLikeGObserver<GSelf>>>>(this: GSelf, callback: GCallback): IPipeLike<GSelf, TInferObservableLikeGObserver<GSelf>>;
  abstract pipeTo<GArgObserver extends TInferObservableLikeGObserver<GSelf>>(this: GSelf, observer: GArgObserver): IPipeLike<GSelf, GArgObserver>;
}
