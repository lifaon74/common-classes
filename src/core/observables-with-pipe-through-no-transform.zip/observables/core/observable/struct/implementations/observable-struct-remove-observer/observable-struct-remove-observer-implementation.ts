import { TGenericObserverLike } from '../../../../observer/observer-types';
import { Impl } from '@lifaon/traits';
import {
  OBSERVABLE_PRIVATE_CONTEXT, TGenericObservableStruct, TInferObservableStructGObserver
} from '../../observable-struct';
import { ObservableStructDispatch } from '../../functions/observable-struct-dispatch';
import { TObservableKeyValueTupleUnion } from '../../../observable-types';
import { TraitObservableRemoveObserver } from '../../../traits/trait-observable-remove-observer';


@Impl()
export class ImplTraitRemoveObserverForObservableStruct<GSelf extends TGenericObservableStruct> extends TraitObservableRemoveObserver<GSelf, TInferObservableStructGObserver<GSelf>> {
  removeObserver(this: GSelf, observer: TInferObservableStructGObserver<GSelf>): GSelf {
    type GObserver = TInferObservableStructGObserver<GSelf>;
    const observers: TGenericObserverLike[] = this[OBSERVABLE_PRIVATE_CONTEXT].observers;
    const index: number = observers.indexOf(observer);
    if (index === -1) {
      throw new Error(`Doesn't contain this Observer`);
    } else {
      observers.splice(index, 1);
      ObservableStructDispatch<GObserver, TObservableKeyValueTupleUnion<GObserver>, 'remove-observer'>(this, 'remove-observer', observer);
      if (observers.length === 0) {
        ObservableStructDispatch<GObserver, TObservableKeyValueTupleUnion<GObserver>, 'inactive'>(this, 'inactive', void 0);
      }
    }
    return this;
  }
}
