import { TGenericObservableLike } from '../../observable-types';
import { Impl } from '@lifaon/traits';
import { TraitObservablePipeToUsingPipeToClass } from '../../traits/trait-observable-pipe-to/trait-observable-pipe-to-using-pipe-to-class';

@Impl()
export class ImplTraitObservablePipeToForObservableStruct<GSelf extends TGenericObservableLike> extends TraitObservablePipeToUsingPipeToClass<GSelf> {
}
