import { TGenericObservableLike } from '../../observable-types';
import { IPipeThroughLike, TPipeThroughLikeGTransformConstraint, } from '../../../pipe-through/pipe-through-types';
import { Trait } from '@lifaon/traits';


@Trait()
export abstract class TraitObservablePipeThroughSoft<GSelf extends TGenericObservableLike> {
  abstract pipeThroughSoft<GTransform extends TPipeThroughLikeGTransformConstraint<GSelf>>(this: GSelf, transform: GTransform): IPipeThroughLike<GSelf, GTransform>;
}
