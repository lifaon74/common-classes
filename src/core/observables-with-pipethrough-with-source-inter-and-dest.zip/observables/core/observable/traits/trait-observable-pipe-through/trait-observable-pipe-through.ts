import { TGenericObservableLike } from '../../observable-types';
import { TInferTransformLikeGObservable } from '../../../transform/transform-types';
import { Trait } from '@lifaon/traits';
import { TPipeThroughLikeGTransformConstraint } from '../../../pipe-through/pipe-through-types';


@Trait()
export abstract class TraitObservablePipeThrough<GSelf extends TGenericObservableLike> {
  abstract pipeThrough<GTransform extends TPipeThroughLikeGTransformConstraint<GSelf>>(this: GSelf, transform: GTransform): TInferTransformLikeGObservable<GTransform>;
}
