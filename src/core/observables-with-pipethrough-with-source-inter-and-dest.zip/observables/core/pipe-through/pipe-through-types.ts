import {
  IObservableLike, TGenericObservableLike, TObservableActiveKeyValueTuple, TObservableInactiveKeyValueTuple
} from '../observable/observable-types';
import { IActivableLike, IsActivableLike } from '../../../activable/activable-types';
import { TraitPipeThroughGetSourceObservable } from './traits/trait-pipe-through-get-source-observable';
import { TraitEventListenerOn, TraitIsImplementedBy } from '@lifaon/traits';
import { TraitPipeThroughGetIntermediateObserver } from './traits/trait-pipe-through-get-intermediate-observer';
import { TGenericObserverLike } from '../observer/observer-types';
import { TraitPipeThroughGetDestinationObservable } from './traits/trait-pipe-through-get-destination-observable';


export interface IPipeThroughLike<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > extends
  // activable traits
  IActivableLike<IPipeThroughLike<GSourceObservable, GIntermediateObserver, GDestinationObservable>>,
  // own traits
  TraitPipeThroughGetSourceObservable<any, GSourceObservable>,
  TraitPipeThroughGetIntermediateObserver<any, GIntermediateObserver>,
  TraitPipeThroughGetDestinationObservable<any, GDestinationObservable>
  //
{
}

export type TGenericPipeThroughLike = IPipeThroughLike<TGenericObservableLike, TGenericObserverLike, TGenericObservableLikeWithEventListenerOnForActiveAndInactive>;

export function IsPipeThroughLike<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  >(value: any): value is IPipeThroughLike<GSourceObservable, GIntermediateObserver, GDestinationObservable> {
  return TraitIsImplementedBy(TraitPipeThroughGetSourceObservable, value)
    && TraitIsImplementedBy(TraitPipeThroughGetIntermediateObserver, value)
    && TraitIsImplementedBy(TraitPipeThroughGetDestinationObservable, value)
    && IsActivableLike(value);
}

/** TYPES **/

type TObservableActiveAndInactiveKeyValueTupleUnion =
  TObservableActiveKeyValueTuple
  | TObservableInactiveKeyValueTuple;

export interface TGenericObservableLikeWithEventListenerOnForActiveAndInactive extends TGenericObservableLike, TraitEventListenerOn<any, TObservableActiveAndInactiveKeyValueTupleUnion> {
}


// export type TPipeThroughLikeGTransformConstraintWithEventListenerOn<GObservable extends TGenericObservableLike> = ITransformLike<TInferObservableLikeGObserver<GObservable>, TGenericObservableLikeWithEventListenerOn>;

// export type TPipeThroughLikeGTransformConstraint<GObservable extends TGenericObservableLike> = ITransformLike<TInferObservableLikeGObserver<GObservable>, TGenericObservableLikeWithEventListenerOn>;
