import {
  IPipeThroughPrivateContext, IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT,
} from '../struct/pipe-through-struct';
import { IObservableLike, IsObservableLike, } from '../../observable/observable-types';
import { ImplTraitToggleForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-toggle-implementation';
import { ImplTraitIsActivatedForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-is-activated-implementation';
import { ImplTraitActivateForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-activate-implementation';
import { ImplTraitDeactivateForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-deactivate-implementation';
import { IsTransformLike } from '../../transform/transform-types';
import { Pipe } from '../../pipe/class/pipe-class';
import { AssembleTraitImplementations, CreatePrivateContext } from '@lifaon/traits';
import { TGenericObservableLikeWithEventListenerOnForActiveAndInactive } from '../pipe-through-types';
import { TGenericObserverLike } from '../../observer/observer-types';
import { ImplTraitGetSourceObservableForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-get-source-observable-implementation';
import { ImplTraitGetIntermediateObserverForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-get-intermediate-observer-implementation';
import { ImplTraitGetDestinationObservableForPipeThroughStruct } from '../struct/implementations/pipe-through-struct-get-destination-observable-implementation';
import { TGenericObservableLike } from '../../../../observables.bcp/core/observable/observable-types';
import { TPipeThroughLikeGTransformConstraint } from '../../../../observables.bcp/core/pipe-through/pipe-through-types';

/** CONSTRUCTOR **/

export function ConstructPipeThrough<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  >(
  instance: IPipeThroughStruct<GSourceObservable, GIntermediateObserver, GDestinationObservable>,
  sourceObservable: GSourceObservable,
  intermediateObserver: GIntermediateObserver,
  destinationObservable: GDestinationObservable,
): void {
  if (!IsObservableLike(sourceObservable)) {
    throw new TypeError(`The argument 'sourceObservable' is not an Observable.`);
  }

  if (!IsTransformLike(intermediateObserver)) {
    throw new TypeError(`The argument 'intermediateObserver' is not a Transform.`);
  }

  if (!IsObservableLike(destinationObservable)) {
    throw new TypeError(`The argument 'destinationObservable' is not an Observable.`);
  }

  CreatePrivateContext<IPipeThroughPrivateContext<GSourceObservable, GIntermediateObserver, GDestinationObservable>>(
    PIPE_THROUGH_PRIVATE_CONTEXT,
    instance,
    {
      sourceObservable,
      intermediateObserver,
      destinationObservable,
      pipe: new Pipe<GSourceObservable, GIntermediateObserver>(sourceObservable, intermediateObserver),
      undo: null,
    },
  );
}

/** CLASS **/

export interface IPipeThroughImplementations<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > extends
  // own implementations coming from activable
  ImplTraitIsActivatedForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>>,
  ImplTraitActivateForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>, GSourceObservable, GIntermediateObserver, GDestinationObservable>,
  ImplTraitDeactivateForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>>,
  ImplTraitToggleForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>>,
  // own implementations
  ImplTraitGetSourceObservableForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>, GSourceObservable, GIntermediateObserver>,
  ImplTraitGetIntermediateObserverForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>, GSourceObservable, GIntermediateObserver>,
  ImplTraitGetDestinationObservableForPipeThroughStruct<IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>, GSourceObservable, GIntermediateObserver, GDestinationObservable>
  //
{
}

export const PipeThroughImplementations = [
  // own implementations coming from activable
  ImplTraitIsActivatedForPipeThroughStruct,
  ImplTraitActivateForPipeThroughStruct,
  ImplTraitDeactivateForPipeThroughStruct,
  ImplTraitToggleForPipeThroughStruct,
  // own implementations
  ImplTraitGetSourceObservableForPipeThroughStruct,
  ImplTraitGetIntermediateObserverForPipeThroughStruct,
  ImplTraitGetDestinationObservableForPipeThroughStruct,
];

export interface IPipeThroughImplementationsConstructor {
  new<// generics
    GSourceObservable extends IObservableLike<GIntermediateObserver>,
    GIntermediateObserver extends TGenericObserverLike,
    GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
    //
    >(): IPipeThroughImplementations<GSourceObservable, GIntermediateObserver, GDestinationObservable>;
}

export interface IPipeThrough<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > extends IPipeThroughStruct<GSourceObservable, GIntermediateObserver, GDestinationObservable>, IPipeThroughImplementations<GSourceObservable, GIntermediateObserver, GDestinationObservable> {
}

const PipeThroughImplementationsConstructor = AssembleTraitImplementations<IPipeThroughImplementationsConstructor>(PipeThroughImplementations);

export class PipeThrough<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > extends PipeThroughImplementationsConstructor<GSourceObservable, GIntermediateObserver, GDestinationObservable> implements IPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable> {

  static fromTransform<GObservable extends TGenericObservableLike, GTransform extends TPipeThroughLikeGTransformConstraint<GObservable>>() {
    throw 'TODO';
  }

  readonly [PIPE_THROUGH_PRIVATE_CONTEXT]: IPipeThroughPrivateContext<GSourceObservable, GIntermediateObserver, GDestinationObservable>;

  constructor(
    sourceObservable: GSourceObservable,
    intermediateObserver: GIntermediateObserver,
    destinationObservable: GDestinationObservable,
  ) {
    super();
    ConstructPipeThrough<GSourceObservable, GIntermediateObserver, GDestinationObservable>(
      this,
      sourceObservable,
      intermediateObserver,
      destinationObservable,
    );
  }
}
