import {
  IPipeThroughPrivateContext,
  IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT, TGenericPipeThroughPrivateContext,
} from '../pipe-through-struct';
import { IObservableLike } from '../../../observable/observable-types';
import { TGenericObserverLike } from '../../../observer/observer-types';
import { Impl, TraitActivate } from '@lifaon/traits';
import { TGenericObservableLikeWithEventListenerOnForActiveAndInactive } from '../../pipe-through-types';


@Impl()
export class ImplTraitActivateForPipeThroughStruct<// generics
  GSelf extends IPipeThroughStruct<GSourceObservable, GIntermediateObserver, GDestinationObservable>,
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
//
  > extends TraitActivate<GSelf, GSelf> {
  activate(this: GSelf): GSelf {
    const context: IPipeThroughPrivateContext<GSourceObservable, GIntermediateObserver, GDestinationObservable> = this[PIPE_THROUGH_PRIVATE_CONTEXT];
    if (context.undo === null) {
      const destinationObservable = context.destinationObservable;
      const undoActiveListener = destinationObservable.on('active', () => context.pipe.activate());
      const undoInactiveListener = destinationObservable.on('inactive', () => context.pipe.deactivate());
      context.undo = () => {
        undoActiveListener();
        undoInactiveListener();
      };
      if (destinationObservable.isActive()) {
        context.pipe.activate();
      }
    }
    return this;
  }
}
