import { IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT, } from '../pipe-through-struct';
import { Impl } from '@lifaon/traits';
import { IObservableLike } from '../../../observable/observable-types';
import { TraitPipeThroughGetIntermediateObserver } from '../../traits/trait-pipe-through-get-intermediate-observer';
import { TGenericObserverLike } from '../../../observer/observer-types';
import { TGenericObservableLikeWithEventListenerOnForActiveAndInactive } from '../../pipe-through-types';

@Impl()
export class ImplTraitGetIntermediateObserverForPipeThroughStruct<// generics
  GSelf extends IPipeThroughStruct<GSourceObservable, GIntermediateObserver, TGenericObservableLikeWithEventListenerOnForActiveAndInactive>,
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike
  //
  > extends TraitPipeThroughGetIntermediateObserver<GSelf, GIntermediateObserver> {
  getIntermediateObserver(this: GSelf): GIntermediateObserver {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].intermediateObserver;
  }
}
