import { IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT, } from '../pipe-through-struct';
import { TraitPipeThroughGetSourceObservable } from '../../traits/trait-pipe-through-get-source-observable';
import { Impl } from '@lifaon/traits';
import { IObservableLike } from '../../../observable/observable-types';
import { TGenericObserverLike } from '../../../observer/observer-types';
import { TGenericObservableLikeWithEventListenerOnForActiveAndInactive } from '../../pipe-through-types';

@Impl()
export class ImplTraitGetSourceObservableForPipeThroughStruct<// generics
  GSelf extends IPipeThroughStruct<GSourceObservable, GIntermediateObserver, TGenericObservableLikeWithEventListenerOnForActiveAndInactive>,
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike
  //
  > extends TraitPipeThroughGetSourceObservable<GSelf, GSourceObservable> {
  getSourceObservable(this: GSelf): GSourceObservable {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].sourceObservable;
  }
}
