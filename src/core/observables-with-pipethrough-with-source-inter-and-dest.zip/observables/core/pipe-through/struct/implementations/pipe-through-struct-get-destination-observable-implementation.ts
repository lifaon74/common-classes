import { IPipeThroughStruct, PIPE_THROUGH_PRIVATE_CONTEXT, } from '../pipe-through-struct';
import { Impl } from '@lifaon/traits';
import { IObservableLike } from '../../../observable/observable-types';
import { TGenericObserverLike } from '../../../observer/observer-types';
import { TraitPipeThroughGetDestinationObservable } from '../../traits/trait-pipe-through-get-destination-observable';
import { TGenericObservableLikeWithEventListenerOnForActiveAndInactive } from '../../pipe-through-types';

@Impl()
export class ImplTraitGetDestinationObservableForPipeThroughStruct<// generics
  GSelf extends IPipeThroughStruct<GSourceObservable, GIntermediateObserver, GDestinationObservable>,
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > extends TraitPipeThroughGetDestinationObservable<GSelf, GDestinationObservable> {
  getDestinationObservable(this: GSelf): GDestinationObservable {
    return this[PIPE_THROUGH_PRIVATE_CONTEXT].destinationObservable;
  }
}
