import { IObservableLike, TGenericObservableLike } from '../../observable/observable-types';
import { IPipeLike } from '../../pipe/pipe-types';
import { HasProperty, IsObject } from '@lifaon/traits';
import { TGenericObserverLike } from '../../observer/observer-types';
import { TGenericObservableLikeWithEventListenerOnForActiveAndInactive } from '../pipe-through-types';

/** PRIVATE CONTEXT **/

export type TUndoFunction = () => void;

export const PIPE_THROUGH_PRIVATE_CONTEXT: unique symbol = Symbol('pipe-through-private-context');

export interface IPipeThroughPrivateContext<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > {
  readonly sourceObservable: GSourceObservable;
  readonly intermediateObserver: GIntermediateObserver;
  readonly destinationObservable: GDestinationObservable;
  pipe: IPipeLike<GSourceObservable, GIntermediateObserver>;
  undo: TUndoFunction | null;
}

export type TGenericPipeThroughPrivateContext = IPipeThroughPrivateContext<TGenericObservableLike, TGenericObserverLike, TGenericObservableLikeWithEventListenerOnForActiveAndInactive>;

/** STRUCT DEFINITION **/

export interface IPipeThroughStruct<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  > {
  readonly [PIPE_THROUGH_PRIVATE_CONTEXT]: IPipeThroughPrivateContext<GSourceObservable, GIntermediateObserver, GDestinationObservable>;
}

export type TGenericPipeThroughStruct = IPipeThroughStruct<TGenericObservableLike, TGenericObserverLike, TGenericObservableLikeWithEventListenerOnForActiveAndInactive>;

export function IsPipeThroughStruct<// generics
  GSourceObservable extends IObservableLike<GIntermediateObserver>,
  GIntermediateObserver extends TGenericObserverLike,
  GDestinationObservable extends TGenericObservableLikeWithEventListenerOnForActiveAndInactive
  //
  >(value: any): value is IPipeThroughStruct<GSourceObservable, GIntermediateObserver, GDestinationObservable> {
  return IsObject(value)
    && HasProperty(value, PIPE_THROUGH_PRIVATE_CONTEXT);
}
