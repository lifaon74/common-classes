import { TGenericObservableLike } from '../../observable/observable-types';
import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitPipeThroughGetSourceObservable<GSelf, GSourceObservable extends TGenericObservableLike> {
  abstract getSourceObservable(this: GSelf): GSourceObservable;
}
