import { Trait } from '@lifaon/traits';
import { TGenericObserverLike } from '../../observer/observer-types';

@Trait()
export abstract class TraitPipeThroughGetIntermediateObserver<GSelf, GIntermediateObserver extends TGenericObserverLike> {
  abstract getIntermediateObserver(this: GSelf): GIntermediateObserver;
}

