import { TGenericObservableLike } from '../../observable/observable-types';
import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitPipeThroughGetDestinationObservable<GSelf, GDestinationObservable extends TGenericObservableLike> {
  abstract getDestinationObservable(this: GSelf): GDestinationObservable;
}
