import {
  TraitEventListenerDispatch, TraitEventListenerIsDispatching, TraitEventListenerOn, TraitIsImplementedBy,
  TGenericKeyValueTupleList
} from '@lifaon/traits';

export interface IEventListenerLike<GKeyValueTupleList extends TGenericKeyValueTupleList> extends TraitEventListenerDispatch<any, any>, // GKeyValueTupleList
  TraitEventListenerIsDispatching<any>,
  TraitEventListenerOn<any, GKeyValueTupleList> {
}

export function IsEventListenerLike<GKeyValueTupleList extends TGenericKeyValueTupleList>(value: any): value is IEventListenerLike<GKeyValueTupleList> {
  return TraitIsImplementedBy(TraitEventListenerDispatch, value)
    && TraitIsImplementedBy(TraitEventListenerIsDispatching, value)
    && TraitIsImplementedBy(TraitEventListenerOn, value);
}

/** TYPES **/


/*
export declare type TKeyValueTuple<GKey, GValue> = [GKey, GValue];
export declare type TGenericKeyValueTuple = TKeyValueTuple<any, any>;
export declare type TEmptyKeyValueTupleUnion = never;
export declare type TGenericKeyValueTupleList = TGenericKeyValueTuple;
export declare type TInferKeyValueTupleGKey<GEventTuple extends TGenericKeyValueTuple> = GEventTuple extends TKeyValueTuple<infer GKey, any> ? GKey : never;
export declare type TInferKeyValueTupleGValue<GEventTuple extends TGenericKeyValueTuple> = GEventTuple extends TKeyValueTuple<any, infer GValue> ? GValue : never;

export declare type TInferKeyValueTupleUnionGKey<GKeyValueTupleList extends TGenericKeyValueTupleList> = GKeyValueTupleList extends TEmptyKeyValueTupleUnion ? TInferKeyValueTupleGKey<GKeyValueTupleList> : any;
// export declare type TInferKeyValueTupleUnionGKey<GKeyValueTupleList extends TGenericKeyValueTupleList> = TInferKeyValueTupleGKey<GKeyValueTupleList>;

export declare type TInferKeyValueTupleUnionGValue<GKeyValueTupleList extends TGenericKeyValueTupleList> = GKeyValueTupleList extends TEmptyKeyValueTupleUnion ? TInferKeyValueTupleGValue<GKeyValueTupleList> : any;
export declare type TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleList extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleList>> = GKeyValueTupleList extends TKeyValueTuple<GKey, infer GValue> ? GValue : never;

export declare type TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleList extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleList>> =
  GKeyValueTupleList extends TEmptyKeyValueTupleUnion
    ? TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleList, GKey>
    : any;

export declare type TKeyValueMapToKeyValueTupleUnion<GObject extends object> = {
    [GKey in Extract<keyof GObject, string>]: TKeyValueTuple<GKey, GObject[GKey]>;
}[Extract<keyof GObject, string>];
export declare type TKeyValueTupleUnionToKeyValueMap<GKeyValueTupleList extends TGenericKeyValueTuple> = {
    [GKey in TInferKeyValueTupleUnionGKey<GKeyValueTupleList>]: GKeyValueTupleList extends TKeyValueTuple<GKey, infer GValue> ? GValue : never;
};

export declare type TKeyValueTupleUnionSuperSetConstraint<GKeyValueTupleList extends TGenericKeyValueTuple, GKeyValueTupleSubSetUnion extends TGenericKeyValueTuple> = [
  GKeyValueTupleSubSetUnion
] extends [GKeyValueTupleList] ? TGenericKeyValueTuple : never;
export declare type TKeyValueTupleUnionSubSetConstraint<GKeyValueTupleList extends TGenericKeyValueTuple, GKeyValueTupleSuperSetUnion extends TGenericKeyValueTuple> = [
  GKeyValueTupleList
] extends [GKeyValueTupleSuperSetUnion] ? TGenericKeyValueTuple : never;
export declare type TInferListenerCallbackFromKeyValueTupleUnionAndKey<GKeyValueTupleList extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleList>> = (value: TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleList, GKey>) => void;
export declare type TGenericListenerCallback = (value: any) => void;
export declare type TEventListenerOnUnsubscribe = () => void;

 */
