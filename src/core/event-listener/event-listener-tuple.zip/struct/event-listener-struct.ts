import {
  HasProperty, IsObject, TGenericKeyValueTupleList, TGenericListenerCallback, TInferKeyValueTupleListKeys
} from '@lifaon/traits';

/** PRIVATE TYPES **/

export interface IListener {
  callback: TGenericListenerCallback;
}

/** PRIVATE CONTEXT **/

export const EVENT_LISTENER_PRIVATE_CONTEXT: unique symbol = Symbol('event-listener-private-context');

export interface IEventListenerPrivateContext<GKeyValueTupleList extends TGenericKeyValueTupleList> {
  listeners: Map<TInferKeyValueTupleListKeys<GKeyValueTupleList>, IListener[]>;
  isDispatching: boolean;
}

export type TEventListenerPrivateContextFromGSelf<GSelf extends TGenericEventListenerStruct> = IEventListenerPrivateContext<TInferEventListenerStructGKeyValueTupleList<GSelf>>;

/** STRUCT DEFINITION **/

export interface IEventListenerStruct<GKeyValueTupleList extends TGenericKeyValueTupleList> {
  readonly [EVENT_LISTENER_PRIVATE_CONTEXT]: IEventListenerPrivateContext<GKeyValueTupleList>;
}

export type TGenericEventListenerStruct = IEventListenerStruct<TGenericKeyValueTupleList>;

export type TInferEventListenerStructGKeyValueTupleList<GEventListenerStruct extends TGenericEventListenerStruct> =
  GEventListenerStruct extends IEventListenerStruct<infer GKeyValueTupleList>
    ? GKeyValueTupleList
    : never;

export function IsEventListenerStruct<GKeyValueTupleList extends TGenericKeyValueTupleList>(value: any): value is IEventListenerStruct<GKeyValueTupleList> {
  return IsObject(value)
    && HasProperty(value, EVENT_LISTENER_PRIVATE_CONTEXT);
}



