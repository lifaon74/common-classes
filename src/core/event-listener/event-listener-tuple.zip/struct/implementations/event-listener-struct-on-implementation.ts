import { Impl, TEventListenerOnUnsubscribe, TraitEventListenerOn } from '@lifaon/traits';
import {
  TGenericKeyValueTupleList, TInferKeyValueTupleListKeys, TInferKeyValueTupleListValueFromKey
} from '@lifaon/traits/src/build-in-traits/event-listener/event-listener-types';
import { TGenericEventListenerStruct } from '../event-listener-struct';

@Impl()
export class ImplTraitEventListenerOnForEventListenerStruct<GSelf extends TGenericEventListenerStruct, GKeyValueTupleList extends TGenericKeyValueTupleList> extends TraitEventListenerOn<GSelf, GKeyValueTupleList> {
  on<GKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>>(
    this: GSelf,
    key: GKey,
    callback: (value: TInferKeyValueTupleListValueFromKey<GKeyValueTupleList, GKey>) => void,
  ): TEventListenerOnUnsubscribe {
    throw 'TODO';
    // const context: IEventListenerPrivateContext<GKeyValueTupleList> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
    // if (context.isDispatching) {
    //   throw GenerateIsDispatchingError();
    // } else {
    //   const listeners: IListener[] = GetListenersHavingName(context.listeners, key);
    //
    //   const listener: IListener = { callback };
    //
    //   listeners.push(listener);
    //
    //   return (): void => {
    //     if (context.isDispatching) {
    //       throw GenerateIsDispatchingError();
    //     } else {
    //       const length: number = listeners.length;
    //       for (let i: number = 0; i < length; i++) {
    //         if (listeners[i] === listener) {
    //           listeners.splice(i, 1);
    //           break;
    //         }
    //       }
    //       if (listeners.length === 0) {
    //         context.listeners.delete(key);
    //       }
    //     }
    //   };
    // }
  }

  // on<GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleList>>(
  //   this: GSelf,
  //   key: GKey,
  //   callback: TInferListenerCallbackFromKeyValueTupleUnionAndKey<GKeyValueTupleList, GKey>,
  // ): TEventListenerOnUnsubscribe {
  //   const context: IEventListenerPrivateContext<GKeyValueTupleList> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
  //   if (context.isDispatching) {
  //     throw GenerateIsDispatchingError();
  //   } else {
  //     const listeners: IListener[] = GetListenersHavingName(context.listeners, key);
  //
  //     const listener: IListener = { callback };
  //
  //     listeners.push(listener);
  //
  //     return (): void => {
  //       if (context.isDispatching) {
  //         throw GenerateIsDispatchingError();
  //       } else {
  //         const length: number = listeners.length;
  //         for (let i: number = 0; i < length; i++) {
  //           if (listeners[i] === listener) {
  //             listeners.splice(i, 1);
  //             break;
  //           }
  //         }
  //         if (listeners.length === 0) {
  //           context.listeners.delete(key);
  //         }
  //       }
  //     };
  //   }
  // }
}


// @Impl()
// export class ImplTraitEventListenerOnForEventListenerStruct<GSelf extends TEmptyEventListenerStruct> extends TraitEventListenerOn<GSelf, TInferEventListenerStructGKeyValueTupleList<GSelf>> {
//   on<GKey extends TInferKeyValueTupleUnionGKey<TInferEventListenerStructGKeyValueTupleList<GSelf>>>(
//     this: GSelf,
//     key: GKey,
//     callback: TInferListenerCallbackFromKeyValueTupleUnionAndKey<TInferEventListenerStructGKeyValueTupleList<GSelf>, GKey>,
//   ): TEventListenerOnUnsubscribe {
//     type GKeyValueTupleList = TInferEventListenerStructGKeyValueTupleList<GSelf>;
//     // type GKeyValueTupleList = TGenericKeyValueTupleList;
//     const context: IEventListenerPrivateContext<GKeyValueTupleList> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
//     if (context.isDispatching) {
//       throw GenerateIsDispatchingError();
//     } else {
//       const listeners: IListener[] = GetListenersHavingName(context.listeners, key);
//
//       const listener: IListener = { callback };
//
//       listeners.push(listener);
//
//       return (): void => {
//         if (context.isDispatching) {
//           throw GenerateIsDispatchingError();
//         } else {
//           const length: number = listeners.length;
//           for (let i: number = 0; i < length; i++) {
//             if (listeners[i] === listener) {
//               listeners.splice(i, 1);
//               break;
//             }
//           }
//           if (listeners.length === 0) {
//             context.listeners.delete(key);
//           }
//         }
//       };
//     }
//   }
// }
