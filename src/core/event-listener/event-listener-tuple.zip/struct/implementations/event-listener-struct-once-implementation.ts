import { Impl, TraitEventListenerOnceUsingOn } from '@lifaon/traits';
import { IEventListenerStruct } from '../event-listener-struct';
import { TraitEventListenerOn } from '@lifaon/traits/src/build-in-traits/event-listener/trait-event-listener-on/trait-event-listener-on';
import { TGenericKeyValueTupleList } from '@lifaon/traits/src/build-in-traits/event-listener/event-listener-types';

export interface ImplTraitEventListenerOnForEventListenerStructGSelfConstraint<GKeyValueTupleList extends TGenericKeyValueTupleList> extends IEventListenerStruct<GKeyValueTupleList>, TraitEventListenerOn<any, GKeyValueTupleList> {
}

@Impl()
export class ImplTraitEventListenerOnceForEventListenerStruct<GSelf extends ImplTraitEventListenerOnForEventListenerStructGSelfConstraint<GKeyValueTupleList>, GKeyValueTupleList extends TGenericKeyValueTupleList> extends TraitEventListenerOnceUsingOn<GSelf, GKeyValueTupleList> {

}
