import {
  EVENT_LISTENER_PRIVATE_CONTEXT, IEventListenerPrivateContext, IEventListenerStruct, IListener,
} from '../struct/event-listener-struct';
import { ImplTraitEventListenerDispatchForEventListenerStruct } from '../struct/implementations/event-listener-struct-dispatch-implementation';
import { ImplTraitEventListenerOnForEventListenerStruct } from '../struct/implementations/event-listener-struct-on-implementation';
import { ImplTraitEventListenerIsDispatchingForEventListenerStruct } from '../struct/implementations/event-listener-struct-is-dispatching-implementation';
import {
  AssembleTraitImplementations, CreatePrivateContext, TGenericKeyValueTupleList, TInferKeyValueTupleListKeys,
} from '@lifaon/traits';
import { ImplTraitEventListenerOnceForEventListenerStruct } from '../struct/implementations/event-listener-struct-once-implementation';


/** CONSTRUCTOR **/

export function ConstructEventListener<GKeyValueTupleList extends TGenericKeyValueTupleList>(
  instance: IEventListenerStruct<GKeyValueTupleList>,
): void {
  CreatePrivateContext<IEventListenerPrivateContext<GKeyValueTupleList>>(
    EVENT_LISTENER_PRIVATE_CONTEXT,
    instance,
    {
      listeners: new Map<Extract<TInferKeyValueTupleListKeys<GKeyValueTupleList>, string>, IListener[]>(),
      isDispatching: false,
    },
  );
}

/** CLASS **/

export interface IEventListener<GKeyValueTupleList extends TGenericKeyValueTupleList> extends IEventListenerStruct<GKeyValueTupleList>,
  // ImplTraitEventListenerDispatchForEventListenerStruct<IEventListener<GKeyValueTupleList>>,
  ImplTraitEventListenerIsDispatchingForEventListenerStruct<IEventListener<GKeyValueTupleList>>,
  ImplTraitEventListenerOnForEventListenerStruct<IEventListener<GKeyValueTupleList>, GKeyValueTupleList>,
  ImplTraitEventListenerOnceForEventListenerStruct<IEventListener<GKeyValueTupleList>, GKeyValueTupleList> {
}


export interface IAssembledEventListenerImplementations {
  new<GKeyValueTupleList extends TGenericKeyValueTupleList>(): IEventListener<GKeyValueTupleList>;
}

export const EventListenerImplementationsCollection = [
  ImplTraitEventListenerDispatchForEventListenerStruct,
  ImplTraitEventListenerIsDispatchingForEventListenerStruct,
  ImplTraitEventListenerOnForEventListenerStruct,
  ImplTraitEventListenerOnceForEventListenerStruct,
];

const AssembledEventListenerImplementations = AssembleTraitImplementations<IAssembledEventListenerImplementations>(EventListenerImplementationsCollection);

export class EventListener<GKeyValueTupleList extends TGenericKeyValueTupleList> extends AssembledEventListenerImplementations<GKeyValueTupleList> implements IEventListener<GKeyValueTupleList> {
  readonly [EVENT_LISTENER_PRIVATE_CONTEXT]: IEventListenerPrivateContext<GKeyValueTupleList>;

  constructor() {
    super();
    ConstructEventListener<GKeyValueTupleList>(this);
  }
}
