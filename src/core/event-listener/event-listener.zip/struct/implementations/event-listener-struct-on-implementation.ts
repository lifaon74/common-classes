import { Impl, PropertyMethod, TEventListenerOnUnsubscribe, TraitEventListenerOn } from '@lifaon/traits';
import { TEmptyEventListenerStruct } from '../event-listener-struct';
import { TTraitEventListenerOnFunction } from '@lifaon/traits/src/build-in-traits/event-listener/trait-event-listener-on/trait-event-listener-on';
import {
  TGenericKeyValueTupleList, TInferKeyValueTupleListKeys, TInferKeyValueTupleListValueFromKey
} from '@lifaon/traits/src/build-in-traits/event-listener/event-listener-types';

@Impl()
export class ImplTraitEventListenerOnForEventListenerStruct<GSelf extends TEmptyEventListenerStruct, GKeyValueTupleList extends TGenericKeyValueTupleList> extends TraitEventListenerOn<GSelf, GKeyValueTupleList> {
  @PropertyMethod(
    function on<GKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>>(
      this: GSelf,
      key: GKey,
      callback: (value: TInferKeyValueTupleListValueFromKey<GKeyValueTupleList, GKey>) => void,
    ): TEventListenerOnUnsubscribe {
      throw 'TODO';
      // const context: IEventListenerPrivateContext<GKeyValueTupleUnion> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
      // if (context.isDispatching) {
      //   throw GenerateIsDispatchingError();
      // } else {
      //   const listeners: IListener[] = GetListenersHavingName(context.listeners, key);
      //
      //   const listener: IListener = { callback };
      //
      //   listeners.push(listener);
      //
      //   return (): void => {
      //     if (context.isDispatching) {
      //       throw GenerateIsDispatchingError();
      //     } else {
      //       const length: number = listeners.length;
      //       for (let i: number = 0; i < length; i++) {
      //         if (listeners[i] === listener) {
      //           listeners.splice(i, 1);
      //           break;
      //         }
      //       }
      //       if (listeners.length === 0) {
      //         context.listeners.delete(key);
      //       }
      //     }
      //   };
      // }
    }
  )
  readonly on!: TTraitEventListenerOnFunction<GSelf, GKeyValueTupleList>;
  // on<GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>>(
  //   this: GSelf,
  //   key: GKey,
  //   callback: TInferListenerCallbackFromKeyValueTupleUnionAndKey<GKeyValueTupleUnion, GKey>,
  // ): TEventListenerOnUnsubscribe {
  //   const context: IEventListenerPrivateContext<GKeyValueTupleUnion> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
  //   if (context.isDispatching) {
  //     throw GenerateIsDispatchingError();
  //   } else {
  //     const listeners: IListener[] = GetListenersHavingName(context.listeners, key);
  //
  //     const listener: IListener = { callback };
  //
  //     listeners.push(listener);
  //
  //     return (): void => {
  //       if (context.isDispatching) {
  //         throw GenerateIsDispatchingError();
  //       } else {
  //         const length: number = listeners.length;
  //         for (let i: number = 0; i < length; i++) {
  //           if (listeners[i] === listener) {
  //             listeners.splice(i, 1);
  //             break;
  //           }
  //         }
  //         if (listeners.length === 0) {
  //           context.listeners.delete(key);
  //         }
  //       }
  //     };
  //   }
  // }
}


// @Impl()
// export class ImplTraitEventListenerOnForEventListenerStruct<GSelf extends TEmptyEventListenerStruct> extends TraitEventListenerOn<GSelf, TInferEventListenerStructGKeyValueTupleUnion<GSelf>> {
//   on<GKey extends TInferKeyValueTupleUnionGKey<TInferEventListenerStructGKeyValueTupleUnion<GSelf>>>(
//     this: GSelf,
//     key: GKey,
//     callback: TInferListenerCallbackFromKeyValueTupleUnionAndKey<TInferEventListenerStructGKeyValueTupleUnion<GSelf>, GKey>,
//   ): TEventListenerOnUnsubscribe {
//     type GKeyValueTupleUnion = TInferEventListenerStructGKeyValueTupleUnion<GSelf>;
//     // type GKeyValueTupleUnion = TGenericKeyValueTupleUnion;
//     const context: IEventListenerPrivateContext<GKeyValueTupleUnion> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
//     if (context.isDispatching) {
//       throw GenerateIsDispatchingError();
//     } else {
//       const listeners: IListener[] = GetListenersHavingName(context.listeners, key);
//
//       const listener: IListener = { callback };
//
//       listeners.push(listener);
//
//       return (): void => {
//         if (context.isDispatching) {
//           throw GenerateIsDispatchingError();
//         } else {
//           const length: number = listeners.length;
//           for (let i: number = 0; i < length; i++) {
//             if (listeners[i] === listener) {
//               listeners.splice(i, 1);
//               break;
//             }
//           }
//           if (listeners.length === 0) {
//             context.listeners.delete(key);
//           }
//         }
//       };
//     }
//   }
// }
