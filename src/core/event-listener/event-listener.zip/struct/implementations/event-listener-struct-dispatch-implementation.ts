import {
  Impl, TInferKeyValueTupleGKey, TInferKeyValueTupleUnionGValueFromKey, TraitEventListenerDispatch
} from '@lifaon/traits';
import {
  EVENT_LISTENER_PRIVATE_CONTEXT, IEventListenerPrivateContext, IListener, TEmptyEventListenerStruct,
  TInferEventListenerStructGKeyValueTupleUnion
} from '../event-listener-struct';
import { GenerateIsDispatchingError } from '../functions/event-listener-struct-functions';
import { TInferKeyValueTupleUnionGKey } from '@lifaon/traits/src/build-in-traits/event-listener/event-listener-types';

@Impl()
export class ImplTraitEventListenerDispatchForEventListenerStruct<GSelf extends TEmptyEventListenerStruct> extends TraitEventListenerDispatch<GSelf, TInferEventListenerStructGKeyValueTupleUnion<GSelf>> {
  dispatch<GKey extends TInferKeyValueTupleUnionGKey<TInferEventListenerStructGKeyValueTupleUnion<GSelf>>>(
    this: GSelf,
    key: GKey,
    value: TInferKeyValueTupleUnionGValueFromKey<TInferEventListenerStructGKeyValueTupleUnion<GSelf>, GKey>,
  ): void {
    type GKeyValueTupleUnion = TInferEventListenerStructGKeyValueTupleUnion<GSelf>;
    // type GKeyValueTupleUnion = TGenericKeyValueTupleUnion;
    const context: IEventListenerPrivateContext<GKeyValueTupleUnion> = this[EVENT_LISTENER_PRIVATE_CONTEXT];
    if (context.isDispatching) {
      throw GenerateIsDispatchingError();
    } else {
      if (context.listeners.has(key)) {
        context.isDispatching = true;
        const listeners: IListener[] = (context.listeners.get(key) as IListener[]);
        for (let i = 0, l = listeners.length; i < l; i++) {
          listeners[i].callback(value);
        }
        context.isDispatching = false;
      }
    }
  }
}
