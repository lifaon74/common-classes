import { Impl, TEmptyTraitEventListenerOn, TraitEventListenerOnceUsingOn } from '@lifaon/traits';
import { TEmptyEventListenerStruct } from '../event-listener-struct';

export interface ImplTraitEventListenerOnForEventListenerStructGSelfConstraint extends TEmptyEventListenerStruct, TEmptyTraitEventListenerOn {
}

@Impl()
export class ImplTraitEventListenerOnceForEventListenerStruct<GSelf extends ImplTraitEventListenerOnForEventListenerStructGSelfConstraint> extends TraitEventListenerOnceUsingOn<GSelf> {
}
