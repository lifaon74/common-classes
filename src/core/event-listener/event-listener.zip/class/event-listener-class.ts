import {
  EVENT_LISTENER_PRIVATE_CONTEXT, IEventListenerPrivateContext, IEventListenerStruct, IListener,
} from '../struct/event-listener-struct';
import { ImplTraitEventListenerDispatchForEventListenerStruct } from '../struct/implementations/event-listener-struct-dispatch-implementation';
import { ImplTraitEventListenerOnForEventListenerStruct } from '../struct/implementations/event-listener-struct-on-implementation';
import { ImplTraitEventListenerIsDispatchingForEventListenerStruct } from '../struct/implementations/event-listener-struct-is-dispatching-implementation';
import {
  AssembleTraitImplementations, CreatePrivateContext, TEmptyKeyValueTupleUnion, TEmptyTraitEventListenerOn,
  TGenericKeyValueTupleUnion, TGenericTraitEventListenerOn,
  TInferKeyValueTupleGKey, TInferKeyValueTupleUnionGValueFromKey, TraitEventListenerOn,
} from '@lifaon/traits';
import { ImplTraitEventListenerOnceForEventListenerStruct } from '../struct/implementations/event-listener-struct-once-implementation';


/** CONSTRUCTOR **/

export function ConstructEventListener<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion>(
  instance: IEventListenerStruct<GKeyValueTupleUnion>,
): void {
  CreatePrivateContext<IEventListenerPrivateContext<GKeyValueTupleUnion>>(
    EVENT_LISTENER_PRIVATE_CONTEXT,
    instance,
    {
      listeners: new Map<Extract<TInferKeyValueTupleGKey<GKeyValueTupleUnion>, string>, IListener[]>(),
      isDispatching: false,
    },
  );
}

/** CLASS **/

export interface IEventListener<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> extends IEventListenerStruct<GKeyValueTupleUnion>,
  // ImplTraitEventListenerDispatchForEventListenerStruct<IEventListener<GKeyValueTupleUnion>>,
  ImplTraitEventListenerIsDispatchingForEventListenerStruct<IEventListener<GKeyValueTupleUnion>>,
  ImplTraitEventListenerOnForEventListenerStruct<IEventListener<GKeyValueTupleUnion>, GKeyValueTupleUnion> {
}

export interface IEventListenerWithOnce<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> extends IEventListener<GKeyValueTupleUnion>,
  ImplTraitEventListenerOnceForEventListenerStruct<IEventListener<Extract<GKeyValueTupleUnion, TGenericKeyValueTupleUnion>>> {
  // ImplTraitEventListenerOnceForEventListenerStruct<IEventListener<GKeyValueTupleUnion>> {
}

export interface IAssembledEventListenerImplementations {
  new<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion>(): IEventListener<GKeyValueTupleUnion>;
}

export const EventListenerImplementationsCollection = [
  ImplTraitEventListenerDispatchForEventListenerStruct,
  ImplTraitEventListenerIsDispatchingForEventListenerStruct,
  ImplTraitEventListenerOnForEventListenerStruct,
  ImplTraitEventListenerOnceForEventListenerStruct,
];

const AssembledEventListenerImplementations = AssembleTraitImplementations<IAssembledEventListenerImplementations>(EventListenerImplementationsCollection);

export class EventListener<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> extends AssembledEventListenerImplementations<GKeyValueTupleUnion> implements IEventListener<GKeyValueTupleUnion> {
  readonly [EVENT_LISTENER_PRIVATE_CONTEXT]: IEventListenerPrivateContext<GKeyValueTupleUnion>;

  constructor() {
    super();
    ConstructEventListener<GKeyValueTupleUnion>(this);
  }
}

// class A<GValue> {
//   a<GKey extends GValue>(value: GKey): void {}
// }
//
// class B<GValue> extends A<GValue> {
//   a<GKey extends GValue>(value: GKey): void {}
// }
//
// // class A<GValue> {
// //   a<GKey extends never>(value: GKey): void {}
// // }
// //
// // class B<GValue> extends A<GValue> {
// //   a<GKey extends ('a' | 'b')>(value: GKey): void {}
// // }
//
// const a1: (('a' | 'b') extends any ? true : false) = true;
// const a2: (('a') extends any ? true : false) = true;
// const a2_1: (('a') extends never ? true : false) = false;
//
// const a3: (B<'a' | 'b'> extends A<any> ? true : false) = true; // error before v3.7
// const a3_1: (B<'a' | 'b'> extends A<never> ? true : false) = true;
// const a4: (B<'a'> extends A<any> ? true : false) = true; // error
// const a4_1: (B<'a'> extends A<never> ? true : false) = true; // error
// const a5: (B<'a'> extends B<any> ? true : false) = true;
//
// type Constrained<G extends A<any>> = true;
//
// const a6: Constrained<A<'a'>> = true; // ok
// const a7: Constrained<B<'a' | 'b'>> = true; // ok
// const a8: Constrained<B<'a'>> = true; // error



// type TMap = ['a', 1 | 3] | ['b', 2];
type TMap = ['a', 1];
type EvtLnr =  IEventListener<TMap>;
const a: IEventListener<TMap> = null as any;
a.on('a', (v: 1 | 3) => {});




const a: (TMap extends TEmptyKeyValueTupleUnion ? true : false); // false
const a: (TMap extends TGenericKeyValueTupleUnion ? true : false); // true

const a: (TraitEventListenerOn<any, TMap> extends TEmptyTraitEventListenerOn ? true : false); // true
const a: (TraitEventListenerOn<any, TMap> extends TGenericTraitEventListenerOn ? true : false); // true
const a: (ImplTraitEventListenerOnForEventListenerStruct<any, TMap> extends TEmptyTraitEventListenerOn ? true : false); // true
const a: (ImplTraitEventListenerOnForEventListenerStruct<any, TMap> extends TGenericTraitEventListenerOn ? true : false); // true
const a: (IEventListener<TMap> extends TraitEventListenerOn<any, TGenericKeyValueTupleUnion> ? true : false);
const a: (IEventListener<TMap> extends TraitEventListenerOn<any, never> ? true : false);


export type TInferTraitEventListenerOnGKeyValueTupleUnion<GTrait extends TEmptyTraitEventListenerOn> =
  GTrait extends TraitEventListenerOn<any, infer GKeyValueTupleUnion>
    ? GKeyValueTupleUnion
    : never;

const a: (((a: string) => void) extends ((a: any) => void) ? true : false);

const a: TInferKeyValueTupleUnionGValueFromKey<TEmptyKeyValueTupleUnion, never>;
// const a: TInferTraitEventListenerOnGKeyValueTupleUnion<IEventListener<TMap>>;
const a: TInferTraitEventListenerOnGKeyValueTupleUnion<ImplTraitEventListenerOnForEventListenerStruct<any, TMap>>;
// const a: TInferTraitEventListenerOnGKeyValueTupleUnion<TraitEventListenerOn<any, TMap>>;
