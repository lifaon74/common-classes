import {
  TraitEventListenerDispatch, TraitEventListenerIsDispatching, TraitEventListenerOn, TraitIsImplementedBy,
  TGenericKeyValueTupleUnion
} from '@lifaon/traits';

export interface IEventListenerLike<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> extends TraitEventListenerDispatch<any, GKeyValueTupleUnion>,
  TraitEventListenerIsDispatching<any>,
  TraitEventListenerOn<any, GKeyValueTupleUnion> {
}

export function IsEventListenerLike<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion>(value: any): value is IEventListenerLike<GKeyValueTupleUnion> {
  return TraitIsImplementedBy(TraitEventListenerDispatch, value)
    && TraitIsImplementedBy(TraitEventListenerIsDispatching, value)
    && TraitIsImplementedBy(TraitEventListenerOn, value);
}

/** TYPES **/


/*
export declare type TKeyValueTuple<GKey, GValue> = [GKey, GValue];
export declare type TGenericKeyValueTuple = TKeyValueTuple<any, any>;
export declare type TEmptyKeyValueTupleUnion = never;
export declare type TGenericKeyValueTupleUnion = TGenericKeyValueTuple;
export declare type TInferKeyValueTupleGKey<GEventTuple extends TGenericKeyValueTuple> = GEventTuple extends TKeyValueTuple<infer GKey, any> ? GKey : never;
export declare type TInferKeyValueTupleGValue<GEventTuple extends TGenericKeyValueTuple> = GEventTuple extends TKeyValueTuple<any, infer GValue> ? GValue : never;

export declare type TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> = GKeyValueTupleUnion extends TEmptyKeyValueTupleUnion ? TInferKeyValueTupleGKey<GKeyValueTupleUnion> : any;
// export declare type TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> = TInferKeyValueTupleGKey<GKeyValueTupleUnion>;

export declare type TInferKeyValueTupleUnionGValue<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> = GKeyValueTupleUnion extends TEmptyKeyValueTupleUnion ? TInferKeyValueTupleGValue<GKeyValueTupleUnion> : any;
export declare type TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> = GKeyValueTupleUnion extends TKeyValueTuple<GKey, infer GValue> ? GValue : never;

export declare type TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> =
  GKeyValueTupleUnion extends TEmptyKeyValueTupleUnion
    ? TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleUnion, GKey>
    : any;

export declare type TKeyValueMapToKeyValueTupleUnion<GObject extends object> = {
    [GKey in Extract<keyof GObject, string>]: TKeyValueTuple<GKey, GObject[GKey]>;
}[Extract<keyof GObject, string>];
export declare type TKeyValueTupleUnionToKeyValueMap<GKeyValueTupleUnion extends TGenericKeyValueTuple> = {
    [GKey in TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>]: GKeyValueTupleUnion extends TKeyValueTuple<GKey, infer GValue> ? GValue : never;
};

export declare type TKeyValueTupleUnionSuperSetConstraint<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKeyValueTupleSubSetUnion extends TGenericKeyValueTuple> = [
  GKeyValueTupleSubSetUnion
] extends [GKeyValueTupleUnion] ? TGenericKeyValueTuple : never;
export declare type TKeyValueTupleUnionSubSetConstraint<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKeyValueTupleSuperSetUnion extends TGenericKeyValueTuple> = [
  GKeyValueTupleUnion
] extends [GKeyValueTupleSuperSetUnion] ? TGenericKeyValueTuple : never;
export declare type TInferListenerCallbackFromKeyValueTupleUnionAndKey<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> = (value: TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleUnion, GKey>) => void;
export declare type TGenericListenerCallback = (value: any) => void;
export declare type TEventListenerOnUnsubscribe = () => void;

 */
