import { Impl } from '@lifaon/traits';
import {
  DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT, IDoublyLinkedListNodeStruct
} from '../doubly-linked-list-node-struct';
import { TraitLinkedListNodeGetPrevious } from '../../../../../../traits/trait-linked-list-node-get-previous/trait-linked-list-node-get-previous';


@Impl()
export class ImplTraitGetPreviousForDoublyLinkedListNodeStruct<GSelf extends IDoublyLinkedListNodeStruct<GValue>, GValue> extends TraitLinkedListNodeGetPrevious<IDoublyLinkedListNodeStruct<GValue>> {
  getPrevious(this: GSelf): IDoublyLinkedListNodeStruct<GValue> | null {
    return this[DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT].previous;
  }
}

