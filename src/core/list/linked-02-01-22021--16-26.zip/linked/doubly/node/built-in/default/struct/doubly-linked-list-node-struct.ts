/** PRIVATE CONTEXT **/

export const DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT: unique symbol = Symbol('doubly-linked-list-node-private-context');

export interface IDoublyLinkedListNodePrivateContext<GValue> {
  value: GValue;
  previous: IDoublyLinkedListNodeStruct<GValue> | null;
  next: IDoublyLinkedListNodeStruct<GValue> | null;
}


// export interface IDoublyLinkedListNodePrivateContext<// generics
//   GValue,
//   GPrevious extends IDoublyLinkedListNodeStruct<GValue>,
//   GNext extends IDoublyLinkedListNodeStruct<GValue>
//   //
//   > {
//   value: GValue;
//   previous: GPrevious | null;
//   next: GNext | null;
// }

/** STRUCT DEFINITION **/

export interface IDoublyLinkedListNodeStruct<GValue> {
  readonly [DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT]: IDoublyLinkedListNodePrivateContext<GValue>;
}

export type IGenericDoublyLinkedListNodeStruct = IDoublyLinkedListNodeStruct<any>;
