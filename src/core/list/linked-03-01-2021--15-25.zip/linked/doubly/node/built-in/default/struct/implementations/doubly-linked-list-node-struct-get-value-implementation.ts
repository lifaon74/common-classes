import { Impl } from '@lifaon/traits';
import {
  DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT, IDoublyLinkedListNodeStruct
} from '../doubly-linked-list-node-struct';
import { TraitLinkedListNodeGetValue } from '../../../../../../traits/trait-linked-list-node-get-value/trait-linked-list-node-get-value';


@Impl()
export class ImplTraitGetValueForDoublyLinkedListNodeStruct<GSelf extends IDoublyLinkedListNodeStruct<GValue>, GValue> extends TraitLinkedListNodeGetValue<IDoublyLinkedListNodeStruct<GValue>, GValue> {
  getValue(this: GSelf): GValue {
    return this[DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT].value;
  }
}

