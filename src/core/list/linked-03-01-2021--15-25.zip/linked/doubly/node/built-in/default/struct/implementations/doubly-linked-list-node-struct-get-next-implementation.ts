import { Impl } from '@lifaon/traits';
import {
  DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT, IDoublyLinkedListNodeStruct
} from '../doubly-linked-list-node-struct';
import { TraitLinkedListNodeGetNext } from '../../../../../../traits/trait-linked-list-node-get-next/trait-linked-list-node-get-next';


@Impl()
export class ImplTraitGetNextForDoublyLinkedListNodeStruct<GSelf extends IDoublyLinkedListNodeStruct<GValue>, GValue> extends TraitLinkedListNodeGetNext<IDoublyLinkedListNodeStruct<GValue>> {
  getNext(this: GSelf): IDoublyLinkedListNodeStruct<GValue> {
    return this[DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT].next;
  }
}

