import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitSingleLinkedListNodeSetNext<GSelf, GNext> {
  abstract setNext(this: GSelf, next: GNext | null): void;
}


