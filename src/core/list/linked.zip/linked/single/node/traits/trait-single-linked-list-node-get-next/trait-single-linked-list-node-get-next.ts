import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitSingleLinkedListNodeGetNext<GSelf, GNext> {
  abstract getNext(this: GSelf): GNext | null;
}


