/** PRIVATE CONTEXT **/

export const SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT: unique symbol = Symbol('single-linked-list-node-private-context');

export interface ISingleLinkedListNodePrivateContext<GNext> {
  next: GNext | null;
}


/** STRUCT DEFINITION **/

export interface ISingleLinkedListNodeStruct<GNext> {
  readonly [SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT]: ISingleLinkedListNodePrivateContext<GNext>;
}

export type TGenericSingleLinkedListNodeStruct = ISingleLinkedListNodeStruct<any>;
