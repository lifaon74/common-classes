import { Impl } from '@lifaon/traits';
import { TraitSingleLinkedListNodeGetNext } from '../../../../traits/trait-single-linked-list-node-get-next/trait-single-linked-list-node-get-next';
import {
  ISingleLinkedListNodeStruct, SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT
} from '../single-linked-list-node-struct';


@Impl()
export class ImplTraitGetNextForSingleLinkedListNodeStruct<GSelf extends ISingleLinkedListNodeStruct<GNext>, GNext> extends TraitSingleLinkedListNodeGetNext<GSelf, GNext> {
  getNext(this: GSelf): GNext | null {
    return this[SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT].next;
  }
}
