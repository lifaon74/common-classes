import { AssembleTraitImplementations, CreatePrivateContext } from '@lifaon/traits';
import { ImplTraitGetNextForSingleLinkedListNodeStruct } from '../struct/implementations/single-linked-list-node-struct-get-next-implementation';
import {
  ISingleLinkedListNodePrivateContext, ISingleLinkedListNodeStruct, SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT
} from '../struct/single-linked-list-node-struct';
import { ImplTraitSetNextForSingleLinkedListNodeStruct } from '../struct/implementations/single-linked-list-node-struct-set-next-implementation';

/** CONSTRUCTOR **/

export function ConstructSingleLinkedListNode<GNext>(
  instance: ISingleLinkedListNodeStruct<GNext>,
): void {
  CreatePrivateContext<ISingleLinkedListNodePrivateContext<GNext>>(
    SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT,
    instance,
    {
      next: null,
    },
  );
}


/** CLASS **/

// FOR PROTOTYPE

export interface ISingleLinkedListNodeImplementations<GNext> extends
  // implementations

  ImplTraitGetNextForSingleLinkedListNodeStruct<ISingleLinkedListNode<GNext>, GNext>,
  ImplTraitSetNextForSingleLinkedListNodeStruct<ISingleLinkedListNode<GNext>, GNext>
  //
{
}

export const SingleLinkedListNodeImplementations = [
  ImplTraitGetNextForSingleLinkedListNodeStruct,
  ImplTraitSetNextForSingleLinkedListNodeStruct,
];

export interface ISingleLinkedListNodeImplementationsConstructor {
  new<GNext>(): ISingleLinkedListNode<GNext>;
}

export interface ISingleLinkedListNode<GNext> extends ISingleLinkedListNodeStruct<GNext>, ISingleLinkedListNodeImplementations<GNext> {
}


const SingleLinkedListNodeImplementationsConstructor = AssembleTraitImplementations<ISingleLinkedListNodeImplementationsConstructor>(SingleLinkedListNodeImplementations);

export class SingleLinkedListNode<GNext> extends SingleLinkedListNodeImplementationsConstructor<GNext> implements ISingleLinkedListNode<GNext> {
  readonly [SINGLE_LINKED_LIST_NODE_PRIVATE_CONTEXT]: ISingleLinkedListNodePrivateContext<GNext>;

  constructor() {
    super();
    ConstructSingleLinkedListNode<GNext>(this);
  }

}
