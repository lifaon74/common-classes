import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitLinkedListNodeGetPrevious<GSelf, GPrevious> {
  abstract getPrevious(this: GSelf): GPrevious | null;
}


