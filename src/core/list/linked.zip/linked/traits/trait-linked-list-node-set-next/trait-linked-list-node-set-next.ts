import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitLinkedListNodeSetNext<GSelf, GNext> {
  abstract setNext(this: GSelf, node: GNext | null): void;
}


