import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitDoublyLinkedListNodeSetPrevious<GSelf, GPrevious> {
  abstract setPrevious(this: GSelf, node: GPrevious | null): void;
}


