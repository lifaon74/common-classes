import { Trait } from '@lifaon/traits';
import { TraitDoublyLinkedListNodeSetPrevious } from '../trait-doubly-linked-list-node-set-previous/trait-doubly-linked-list-node-set-previous';
import { TraitDoublyLinkedListNodeInsertAfter } from './trait-doubly-linked-list-node-insert-after';
import { TraitDoublyLinkedListNodeGetPrevious } from '../trait-doubly-linked-list-node-get-previous/trait-doubly-linked-list-node-get-previous';
import { TraitSingleLinkedListNodeGetNext } from '../../../../single/node/traits/trait-single-linked-list-node-get-next/trait-single-linked-list-node-get-next';
import { TraitSingleLinkedListNodeSetNext } from '../../../../single/node/traits/trait-single-linked-list-node-set-next/trait-single-linked-list-node-set-next';

// export interface ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGSelfConstraint<// generics
//   GNext extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<any>,
//   //
//   > extends
//   // traits
//   TraitSingleLinkedListNodeGetNext<any, GNext>,
//   TraitSingleLinkedListNodeSetNext<any, GNext>
//   //
// {
// }
//
// // TraitDoublyLinkedListNodeGetPrevious<any, GPrevious>,
// // TraitSingleLinkedListNodeGetNext<any, GNext>,
// // TraitDoublyLinkedListNodeSetPrevious<any, GPrevious>,
// // TraitSingleLinkedListNodeSetNext<any, GNext>
//
// export interface ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GCurrent> extends
//   // traits
//   TraitDoublyLinkedListNodeSetPrevious<any, ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GCurrent>>,
//   TraitSingleLinkedListNodeSetNext<any, ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GCurrent>>
//   //
// {
// }
//
//
// @Trait()
// export abstract class TraitDoublyLinkedListNodeInsertAfterUsingGetSetNextPrevious<// generics
//   GSelf extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGSelfConstraint<GNext>,
//   GNext extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GSelf>,
//   //
//   > extends TraitDoublyLinkedListNodeInsertAfter<GSelf, GNext> {
//   insertAfter(this: GSelf, next: GNext): void {
//     const _next: GNext | null = this.getNext();
//     if (_next !== null) {
//       _next.setPrevious(next);
//     }
//     next.setNext(_next);
//     this.setNext(next);
//     next.setPrevious(this);
//   }
// }
//


export interface ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGSelfConstraint<GSelf> extends
  // traits
  TraitDoublyLinkedListNodeGetPrevious<any, GSelf>,
  TraitDoublyLinkedListNodeSetPrevious<any, GSelf>,
  TraitSingleLinkedListNodeGetNext<any, GSelf>,
  TraitSingleLinkedListNodeSetNext<any, GSelf>
  //
{
}


@Trait()
export abstract class TraitDoublyLinkedListNodeInsertAfterUsingGetSetNextPrevious<// generics
  GSelf extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGSelfConstraint<GSelf>,
  //
  > extends TraitDoublyLinkedListNodeInsertAfter<GSelf, GSelf> {
  insertAfter(this: GSelf, next: GSelf): void {
    // properly detach 'next'
    // -> properly re-attach next.previous
    const __previous: GSelf | null = next.getPrevious();
    if (__previous !== null) {
      __previous.setNext(next.getNext());
    }

    // -> properly re-attach next.next
    const __next: GSelf | null = next.getNext();
    if (__next !== null) {
      __next.setPrevious(next.getPrevious());
    }

    const _next: GSelf | null = this.getNext();
    if (_next !== null) {
      _next.setPrevious(next);
    }
    next.setNext(_next);
    this.setNext(next);
    next.setPrevious(this);
  }
}


