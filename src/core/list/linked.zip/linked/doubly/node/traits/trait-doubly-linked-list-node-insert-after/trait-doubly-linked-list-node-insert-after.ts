import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitDoublyLinkedListNodeInsertAfter<GSelf, GNext> {
  abstract insertAfter(this: GSelf, next: GNext): void;
}


