import { Trait } from '@lifaon/traits';

@Trait()
export abstract class TraitDoublyLinkedListNodeGetPrevious<GSelf, GPrevious> {
  abstract getPrevious(this: GSelf): GPrevious | null;
}


