import { Trait } from '@lifaon/traits';
import { TraitSingleLinkedListNodeGetNext } from 'src/core/list/linked/single/node/traits/trait-single-linked-list-node-get-next/trait-single-linked-list-node-get-next';
import { TraitSingleLinkedListNodeSetNext } from 'src/core/list/linked/single/node/traits/trait-single-linked-list-node-set-next/trait-single-linked-list-node-set-next';
import { TraitDoublyLinkedListNodeGetPrevious } from '../trait-doubly-linked-list-node-get-previous/trait-doubly-linked-list-node-get-previous';
import { TraitDoublyLinkedListNodeSetPrevious } from '../trait-doubly-linked-list-node-set-previous/trait-doubly-linked-list-node-set-previous';
import { TraitDoublyLinkedListNodeDetach } from './trait-doubly-linked-list-node-detach';

export interface ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGSelfConstraint<// generics
  GPrevious extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGPreviousConstraint<GNext>,
  GNext extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GPrevious>,
  //
  > extends
  // traits
  TraitDoublyLinkedListNodeGetPrevious<any, GPrevious>,
  TraitSingleLinkedListNodeGetNext<any, GNext>,
  TraitDoublyLinkedListNodeSetPrevious<any, GPrevious>,
  TraitSingleLinkedListNodeSetNext<any, GNext>
  //
{
}


export interface ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGPreviousConstraint<GNext> extends
  // traits
  TraitSingleLinkedListNodeSetNext<any, GNext>
  //
{
}

export interface ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GPrevious> extends
  // traits
  TraitDoublyLinkedListNodeSetPrevious<any, GPrevious>
  //
{
}

@Trait()
export abstract class TraitDoublyLinkedListNodeDetachUsingGetSetNextPrevious<// generics
  GSelf extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGSelfConstraint<GPrevious, GNext>,
  GPrevious extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGPreviousConstraint<GNext>,
  GNext extends ITraitDoublyLinkedListNodeDetachUsingGetSetNextPreviousGNextConstraint<GPrevious>,
  //
  > extends TraitDoublyLinkedListNodeDetach<GSelf> {
  detach(this: GSelf): void {
    const previous: GPrevious | null = this.getPrevious();
    if (previous !== null) {
      previous.setNext(this.getNext());
    }
    this.setPrevious(null);

    const next: GNext | null = this.getNext();
    if (next !== null) {
      next.setPrevious(this.getPrevious());
    }
    this.setNext(null);
  }
}


