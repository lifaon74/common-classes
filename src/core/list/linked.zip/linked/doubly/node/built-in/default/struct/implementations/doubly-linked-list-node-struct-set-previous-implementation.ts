import { Impl } from '@lifaon/traits';
import {
  DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT, IDoublyLinkedListNodeStruct
} from '../doubly-linked-list-node-struct';
import { TraitLinkedListNodeSetPrevious } from '../../../../../../traits/trait-linked-list-node-set-previous/trait-linked-list-node-set-previous';


@Impl()
export class ImplTraitSetPreviousForDoublyLinkedListNodeStruct<GSelf extends IDoublyLinkedListNodeStruct<GValue>, GValue> extends TraitLinkedListNodeSetPrevious<IDoublyLinkedListNodeStruct<GValue>> {
  setPrevious(this: GSelf, node: IDoublyLinkedListNodeStruct<GValue> | null): void {
    this[DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT].previous = node;
  }
}

