import { AssembleTraitImplementations, CreatePrivateContext } from '@lifaon/traits';
import { ImplTraitGetNextForDoublyLinkedListNodeStruct } from '../struct/implementations/doubly-linked-list-node-struct-get-next-implementation';
import {
  IDoublyLinkedListNodePrivateContext, IDoublyLinkedListNodeStruct, DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT
} from '../struct/doubly-linked-list-node-struct';
import { ImplTraitSetNextForDoublyLinkedListNodeStruct } from '../struct/implementations/doubly-linked-list-node-struct-set-next-implementation';
import { ImplTraitSetPreviousForDoublyLinkedListNodeStruct } from '../struct/implementations/doubly-linked-list-node-struct-set-previous-implementation';
import { ImplTraitGetPreviousForDoublyLinkedListNodeStruct } from '../struct/implementations/doubly-linked-list-node-struct-get-previous-implementation';
import { ImplTraitSetValueForDoublyLinkedListNodeStruct } from '../struct/implementations/doubly-linked-list-node-struct-set-value-implementation';
import { ImplTraitGetValueForDoublyLinkedListNodeStruct } from '../struct/implementations/doubly-linked-list-node-struct-get-value-implementation';

/** CONSTRUCTOR **/

export function ConstructDoublyLinkedListNode<GValue>(
  instance: IDoublyLinkedListNodeStruct<GValue>,
  value: GValue,
): void {
  CreatePrivateContext<IDoublyLinkedListNodePrivateContext<GValue>>(
    DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT,
    instance,
    {
      previous: null,
      next: null,
      value: value,
    },
  );
}


/** CLASS **/

// FOR PROTOTYPE

export interface IDoublyLinkedListNodeImplementations<GValue> extends
  // implementations

  // previous
  ImplTraitGetPreviousForDoublyLinkedListNodeStruct<IDoublyLinkedListNode<GValue>, GValue>,
  ImplTraitSetPreviousForDoublyLinkedListNodeStruct<IDoublyLinkedListNode<GValue>, GValue>,
  // next
  ImplTraitGetNextForDoublyLinkedListNodeStruct<IDoublyLinkedListNode<GValue>, GValue>,
  ImplTraitSetNextForDoublyLinkedListNodeStruct<IDoublyLinkedListNode<GValue>, GValue>,
  // value
  ImplTraitGetValueForDoublyLinkedListNodeStruct<IDoublyLinkedListNode<GValue>, GValue>,
  ImplTraitSetValueForDoublyLinkedListNodeStruct<IDoublyLinkedListNode<GValue>, GValue>
  //
{
}

export const DoublyLinkedListNodeImplementations = [
  ImplTraitGetPreviousForDoublyLinkedListNodeStruct,
  ImplTraitSetPreviousForDoublyLinkedListNodeStruct,
  ImplTraitGetNextForDoublyLinkedListNodeStruct,
  ImplTraitSetNextForDoublyLinkedListNodeStruct,
  ImplTraitGetValueForDoublyLinkedListNodeStruct,
  ImplTraitSetValueForDoublyLinkedListNodeStruct,
];

export interface IDoublyLinkedListNodeImplementationsConstructor {
  new<GValue>(): IDoublyLinkedListNode<GValue>;
}

export interface IDoublyLinkedListNode<GValue> extends IDoublyLinkedListNodeStruct<GValue>, IDoublyLinkedListNodeImplementations<GValue> {
}


const DoublyLinkedListNodeImplementationsConstructor = AssembleTraitImplementations<IDoublyLinkedListNodeImplementationsConstructor>(DoublyLinkedListNodeImplementations);

export class DoublyLinkedListNode<GValue> extends DoublyLinkedListNodeImplementationsConstructor<GValue> implements IDoublyLinkedListNode<GValue> {
  readonly [DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT]: IDoublyLinkedListNodePrivateContext<GValue>;

  constructor(
    value: GValue,
  ) {
    super();
    ConstructDoublyLinkedListNode<GValue>(this, value);
  }

}
