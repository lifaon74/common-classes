import { Impl } from '@lifaon/traits';
import {
  DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT, IDoublyLinkedListNodeStruct
} from '../doubly-linked-list-node-struct';
import { TraitLinkedListNodeSetNext } from '../../../../../../traits/trait-linked-list-node-set-next/trait-linked-list-node-set-next';


@Impl()
export class ImplTraitSetNextForDoublyLinkedListNodeStruct<GSelf extends IDoublyLinkedListNodeStruct<GValue>, GValue> extends TraitLinkedListNodeSetNext<IDoublyLinkedListNodeStruct<GValue>> {
  setNext(this: GSelf, node: IDoublyLinkedListNodeStruct<GValue> | null): void {
    this[DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT].next = node;
  }
}

