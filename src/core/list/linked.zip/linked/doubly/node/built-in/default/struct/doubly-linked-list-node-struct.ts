/** PRIVATE CONTEXT **/

export const DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT: unique symbol = Symbol('doubly-linked-list-node-private-context');

export interface IDoublyLinkedListNodePrivateContext<GValue> {
  value: GValue;
  previous: IDoublyLinkedListNodeStruct<GValue>;
  next: IDoublyLinkedListNodeStruct<GValue>;
}

/** STRUCT DEFINITION **/

export interface IDoublyLinkedListNodeStruct<// generics
  GValue,
  //
  > {
  readonly [DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT]: IDoublyLinkedListNodePrivateContext<GValue>;
}

export type IGenericDoublyLinkedListNodeStruct = IDoublyLinkedListNodeStruct<any>;

// export interface IDoublyLinkedListNodePrivateContext<// generics
//   GValue,
//   GPrevious extends IGenericDoublyLinkedListNodeStruct,
//   GNext extends IGenericDoublyLinkedListNodeStruct
//   //
//   > {
//   value: GValue;
//   previous: GPrevious | null;
//   next: GNext | null;
// }
//
// /** STRUCT DEFINITION **/
//
// export interface IDoublyLinkedListNodeStruct<// generics
//   GValue,
//   GPrevious extends IDoublyLinkedListNodeStruct<GValue>,
//   GNext extends IDoublyLinkedListNodeStruct<GValue>
//   //
//   > {
//   readonly [DOUBLY_LINKED_LIST_NODE_PRIVATE_CONTEXT]: IDoublyLinkedListNodePrivateContext<GValue>;
// }
//
// export type IGenericDoublyLinkedListNodeStruct = IDoublyLinkedListNodeStruct<any>;
