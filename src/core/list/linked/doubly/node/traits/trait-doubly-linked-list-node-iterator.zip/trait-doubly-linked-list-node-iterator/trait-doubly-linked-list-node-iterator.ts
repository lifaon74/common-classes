import { Trait } from '@lifaon/traits';

export interface ITraitDoublyLinkedListNodeIteratorOptions {
  reverse?: boolean; // (default: false)
}

@Trait()
export abstract class TraitDoublyLinkedListNodeIterator<GSelf> {
  abstract [Symbol.iterator](
    this: GSelf,
    options?: ITraitDoublyLinkedListNodeIteratorOptions,
  ): Iterator<GSelf>;
}


