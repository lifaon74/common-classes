import { Trait } from '@lifaon/traits';
import {
  ITraitDoublyLinkedListNodeIteratorOptions, TraitDoublyLinkedListNodeIterator
} from './trait-doubly-linked-list-node-iterator';


@Trait()
export abstract class TraitDoublyLinkedListNodeIteratorUsingGetNextAndPrevious<GSelf> extends TraitDoublyLinkedListNodeIterator<GSelf> {
  * [Symbol.iterator](
    this: GSelf,
    {
      reverse = false,
    }: ITraitDoublyLinkedListNodeIteratorOptions = {},
  ): Iterator<GSelf> {
    let node: GSelf = this;
    do {
      yield node;
    } while (node !== this);
  }
}


