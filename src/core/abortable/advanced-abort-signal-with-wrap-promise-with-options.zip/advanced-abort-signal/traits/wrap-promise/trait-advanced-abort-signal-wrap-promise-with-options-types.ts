import { TGenericAdvancedAbortControllerLike } from '../../../advanced-abort-controller/advanced-abort-controller-types';
import { TNativePromiseLikeOrValue } from '../../../../promise/promise-types';


/* ABORT STRATEGY */

// list of strategies to apply to a promise when aborted
export type TAbortStrategy =
  'resolve' // resolve the promise with void
  | 'reject' // reject the promise with the AdvancedAbortSignal's reason
  | 'never' // (default) never resolve the promise, it stays in a pending state forever
  ;

export type TInferAbortStrategyReturn<GStrategy extends TAbortStrategy> =
  GStrategy extends 'resolve'
    ? void
    : (
      GStrategy extends 'reject'
        ? never
        : never
      );

/* WRAP PROMISE */

// infers the returned promise supporting an AdvancedAbortSignal
export type TInferAbortStrategyReturnedPromise<GValue, GStrategy extends TAbortStrategy, GAborted> =
  Promise<GValue | TInferAbortStrategyReturn<GStrategy> | GAborted>;


// export interface IAdvancedAbortSignalWrapPromiseOptions<
//   GStrategy extends TAbortStrategy,
//   GAborted,
//   GAdvancedAbortController extends TGenericAdvancedAbortControllerLike
// > {
//   strategy?: GStrategy; // (default: 'never') how to resolve the promise if signal is aborted
//   onAborted?: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController>; // callback to call when the signal is aborted => we may change the promise state from 'aborted' to something else
//   onAbortedController?: GAdvancedAbortController; // controller provided to the 'onAborted' function
// }
//
// export type IGenericAdvancedAbortSignalWrapPromiseOptions = IAdvancedAbortSignalWrapPromiseOptions<TAbortStrategy, any, TGenericAdvancedAbortControllerLike>;
//
// export type TInferAdvancedAbortSignalWrapPromiseOptionsGStrategy<GOptions extends IGenericAdvancedAbortSignalWrapPromiseOptions> =
//   TDefaultType<GOptions['strategy'], 'never'>;
//
// export type TInferAdvancedAbortSignalWrapPromiseOptionsGAdvancedAbortController<GOptions extends IGenericAdvancedAbortSignalWrapPromiseOptions> =
//   TDefaultType<GOptions['onAbortedController'], TGenericAdvancedAbortControllerLike>;
//
// const a: TInferAdvancedAbortSignalWrapPromiseOptionsGStrategy<{ strategy: 'resolve' }>;
// const a: TInferAdvancedAbortSignalWrapPromiseOptionsGStrategy<{}>;
// const a: TInferAdvancedAbortSignalWrapPromiseOptionsGStrategy<{ strategy: undefined }>;
// const a: TInferAdvancedAbortSignalWrapPromiseOptionsGStrategy<{ strategy: TAbortStrategy }>;

//  the second argument which may be provided to the 'wrapPromise' of an an AdvancedAbortSignal
export type TAdvancedAbortSignalWrapPromiseOptions<GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike> =
  IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted<GStrategy>
  | IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndWithoutOnAbortedController<GStrategy, GAborted>
  | IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController<GStrategy, GAborted, GAdvancedAbortController>;

export interface IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted<GStrategy extends TAbortStrategy> {
  strategy: GStrategy; // (default: 'never') how to resolve the promise if signal is aborted
}

export interface IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndWithoutOnAbortedController<GStrategy extends TAbortStrategy, GAborted> extends IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted<GStrategy> {
  onAborted: TCatchAbortedCallback<GAborted, GStrategy, TGenericAdvancedAbortControllerLike>; // called when the signal is aborted => we may change the promise state from 'aborted' to something else
}

export interface IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController<GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike> extends IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted<GStrategy> {
  onAborted: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController>;
  onAbortedController: GAdvancedAbortController; // controller provided to the 'onAborted' function
}


// definition of the callback to call when the signal is aborted
export type TCatchAbortedCallback<GAborted, GStrategy extends TAbortStrategy, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike> = (
  reason: any,
  newController: GAdvancedAbortController // a new controller is provided if we want to abort the promise
) => TNativePromiseLikeOrValue<GAborted | TInferAbortStrategyReturn<GStrategy>>;
