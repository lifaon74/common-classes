import { Trait } from '@lifaon/traits';
import type { TGenericAdvancedAbortControllerLike } from '../../../advanced-abort-controller/advanced-abort-controller-types';
import { TraitAdvancedAbortSignalWrapPromise } from './trait-advanced-abort-signal-wrap-promise';
import type {
  IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController,
  IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndWithoutOnAbortedController,
  IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted, TAbortStrategy,
  TInferAbortStrategyReturnedPromise
} from './trait-advanced-abort-signal-wrap-promise-with-options-types';
import type { TAdvancedAbortSignalWrapPromiseArgument } from './trait-advanced-abort-signal-wrap-promise-types';


@Trait()
export abstract class TraitAdvancedAbortSignalWrapPromiseWithOptions<GSelf> extends TraitAdvancedAbortSignalWrapPromise<GSelf> {
  abstract wrapPromise<GValue>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
  ): TInferAbortStrategyReturnedPromise<GValue, 'never', never>;

  abstract wrapPromise<GValue, GStrategy extends TAbortStrategy>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options: IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted<GStrategy>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, never>;

  abstract wrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options: IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndWithoutOnAbortedController<GStrategy, GAborted>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted>;

  abstract wrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options: IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController<GStrategy, GAborted, GAdvancedAbortController>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted>;

  // abstract wrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
  //   this: GSelf,
  //   promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
  //   options?: TAdvancedAbortSignalWrapPromiseOptions<GStrategy, GAborted, GAdvancedAbortController>,
  // ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted>;
}
