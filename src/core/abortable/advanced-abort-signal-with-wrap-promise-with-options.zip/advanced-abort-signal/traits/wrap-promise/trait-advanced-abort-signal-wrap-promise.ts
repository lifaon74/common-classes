import { Trait } from '@lifaon/traits';
import { TAdvancedAbortSignalWrapPromiseArgument } from './trait-advanced-abort-signal-wrap-promise-types';

@Trait()
export abstract class TraitAdvancedAbortSignalWrapPromise<GSelf> {
  abstract wrapPromise<GValue>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
  ): Promise<GValue>;
}

