import { TNativePromiseLikeOrValue } from '../../../../promise/promise-types';

// a callback which may be provided to the 'wrapFunction' of an an AdvancedAbortSignal
export type TAdvancedAbortSignalWrapPromiseCallback<GValue> = (
  resolve: (value?: TNativePromiseLikeOrValue<GValue>) => void,
  reject: (reason?: any) => void,
  // signal: IAdvancedAbortSignal
) => void;

// the first argument which may be provided to the 'wrapPromise' of an an AdvancedAbortSignal
export type TAdvancedAbortSignalWrapPromiseArgument<GValue> =
  PromiseLike<GValue>
  | TAdvancedAbortSignalWrapPromiseCallback<GValue>;
