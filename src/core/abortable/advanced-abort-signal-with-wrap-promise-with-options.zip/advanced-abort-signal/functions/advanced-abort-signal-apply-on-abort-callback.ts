import {
  TAbortStrategy, TAdvancedAbortSignalWrapPromiseOptions, TInferAbortStrategyReturn, TInferAbortStrategyReturnedPromise
} from '../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';
import { TGenericAdvancedAbortControllerLike } from '../../advanced-abort-controller/advanced-abort-controller-types';
import { TNativePromiseLikeOrValue } from '../../../promise/promise-types';
import {
  AdvancedAbortSignalRaceAborted, IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal
} from './advanced-abort-signal-race-aborted';


export interface IAdvancedAbortSignalApplyOnAbortCallbackAdvancedAbortSignal extends IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal {
}

// export function AdvancedAbortSignalWrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
//   advancedAbortSignal: IAdvancedAbortSignalWrapPromiseAdvancedAbortSignal,
//   promise: PromiseLike<GValue>,
//   options?: TAdvancedAbortSignalWrapPromiseOptions<GStrategy, GAborted, GAdvancedAbortController>,
// ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted> {
//   return AdvancedAbortSignalRaceAborted<GValue>(advancedAbortSignal, promise)
//     .then((value: GValue | void): TNativePromiseLikeOrValue<GValue | TInferAbortStrategyReturn<GStrategy> | GAborted> => {
//       return advancedAbortSignal.isAborted()
//         ? ApplyOnAbortCallback<GStrategy, GAborted>(advancedAbortSignal, options)
//         : value as GValue;
//     }, (error: any): TNativePromiseLikeOrValue<never | TInferAbortStrategyReturn<GStrategy> | GAborted> => {
//       if (advancedAbortSignal.isAborted()) {
//         return ApplyOnAbortCallback<GStrategy, GAborted>(advancedAbortSignal, options);
//       } else {
//         throw error;
//       }
//     });
// }

/**
 * Calls the 'onAborted' function
 *  - if undefined => applies specified abort strategy
 *  - else calls 'onAborted' with a new controller, and returns the result wrapped by this controller's signal
 */
export function AdvancedAbortSignalApplyOnAbortCallback<TStrategy extends TAbortStrategy, TAborted>(
  advancedAbortSignal: IAdvancedAbortSignalApplyOnAbortCallbackAdvancedAbortSignal,
  options: IAdvancedAbortSignalWrapPromiseNormalizedOptions<TStrategy, TAborted>,
): Promise<TAborted | TInferAbortStrategyReturn<TStrategy>> {
  type T = TAborted | TInferAbortStrategyReturn<TStrategy>;
  if (typeof options.onAborted === 'function') {
    const newController: IAdvancedAbortController = options.onAbortedController as IAdvancedAbortController;
    return newController.signal.wrapPromise<T, TStrategy, never>(
      PromiseTry<T>(() => (options.onAborted as Function).call(instance, instance.reason, newController)),
      {
        strategy: options.strategy,
      }
    );
  } else {
    return ApplyAbortStrategyUsingAdvancedAbortSignalReason<TStrategy>(instance, options.strategy);
  }
}
