import {
  TAbortStrategy, TInferAbortStrategyReturn
} from '../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';


/**
 * Returns a Promise with an abort strategy:
 *  - never: never resolves
 *  - resolve: resolves with undefined
 *  - reject: rejects with instance.reason
 */
export function ApplyAbortStrategy<GStrategy extends TAbortStrategy>(strategy?: GStrategy, reason?: string): Promise<TInferAbortStrategyReturn<GStrategy>> {
  switch (strategy) {
    case void 0:
    case 'never':
      return new Promise<TInferAbortStrategyReturn<GStrategy>>(() => {
      });
    case 'resolve':
      return Promise.resolve<TInferAbortStrategyReturn<GStrategy>>(void 0 as TInferAbortStrategyReturn<GStrategy>);
    case 'reject':
      return Promise.reject<TInferAbortStrategyReturn<GStrategy>>(reason);
    default:
      throw new TypeError(`Unexpected strategy: ${ strategy }`);
  }
}
