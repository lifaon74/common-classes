import {
  TAbortStrategy, TAdvancedAbortSignalWrapPromiseOptions, TInferAbortStrategyReturn, TInferAbortStrategyReturnedPromise
} from '../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';
import { TGenericAdvancedAbortControllerLike } from '../../advanced-abort-controller/advanced-abort-controller-types';
import { TNativePromiseLikeOrValue } from '../../../promise/promise-types';
import {
  AdvancedAbortSignalRaceAborted, IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal
} from './advanced-abort-signal-race-aborted';


export interface IAdvancedAbortSignalWrapPromiseAdvancedAbortSignal extends IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal {
}

export function AdvancedAbortSignalWrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
  advancedAbortSignal: IAdvancedAbortSignalWrapPromiseAdvancedAbortSignal,
  promise: PromiseLike<GValue>,
  options?: TAdvancedAbortSignalWrapPromiseOptions<GStrategy, GAborted, GAdvancedAbortController>,
): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted> {
  return AdvancedAbortSignalRaceAborted<GValue>(advancedAbortSignal, promise)
    .then((value: GValue | void): TNativePromiseLikeOrValue<GValue | TInferAbortStrategyReturn<GStrategy> | GAborted> => {
      return advancedAbortSignal.isAborted()
        ? ApplyOnAbortCallback<GStrategy, GAborted>(advancedAbortSignal, options)
        : value as GValue;
    }, (error: any): TNativePromiseLikeOrValue<never | TInferAbortStrategyReturn<GStrategy> | GAborted> => {
      if (advancedAbortSignal.isAborted()) {
        return ApplyOnAbortCallback<GStrategy, GAborted>(advancedAbortSignal, options);
      } else {
        throw error;
      }
    });
}
