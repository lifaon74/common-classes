import {
  TAbortStrategy, TCatchAbortedCallback
} from '../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';
import {
  IsAdvancedAbortControllerLike, TGenericAdvancedAbortControllerLike
} from '../../../advanced-abort-controller/advanced-abort-controller-types';
import { AdvancedAbortController } from '../../../advanced-abort-controller/class/advanced-abort-controller-class';

export function NormalizeAdvancedAbortSignalWrapPromiseOptionsOnAbortedController<GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
  onAborted?: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController>,
  onAbortedController?: GAdvancedAbortController,
  defaultValue: GAdvancedAbortController | undefined = void 0
): GAdvancedAbortController | undefined {
  if (onAbortedController === void 0) {
    return (onAborted === void 0)
      ? void 0
      : (
        IsAdvancedAbortControllerLike(defaultValue)
          ? defaultValue
          : new AdvancedAbortController() as unknown as GAdvancedAbortController
      );
  } else if (IsAdvancedAbortControllerLike(onAbortedController)) {
    if (onAborted === void 0) {
      throw new Error(`options.onAbortedController is defined but options.onAborted is missing`);
    } else {
      return onAbortedController;
    }
  } else {
    throw new TypeError(`Expected AdvancedAbortController or void as options.onAbortedController`);
  }
}
