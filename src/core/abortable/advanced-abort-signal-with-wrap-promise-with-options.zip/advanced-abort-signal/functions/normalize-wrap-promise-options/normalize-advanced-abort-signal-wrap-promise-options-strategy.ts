import { TAbortStrategy } from '../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';


export function NormalizeAdvancedAbortSignalWrapPromiseOptionsStrategy<GStrategy extends TAbortStrategy>(
  strategy?: GStrategy,
  defaultValue: TAbortStrategy = 'never'
): GStrategy {
  if (strategy === void 0) {
    return defaultValue as GStrategy;
  } else if (['resolve', 'reject', 'never'].includes(strategy)) {
    return strategy;
  } else {
    throw new TypeError(`Expected 'resolve', 'reject', 'never' or void as strategy`);
  }
}
