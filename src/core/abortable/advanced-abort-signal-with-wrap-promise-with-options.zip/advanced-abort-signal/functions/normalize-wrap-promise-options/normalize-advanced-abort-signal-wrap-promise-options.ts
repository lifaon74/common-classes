import {
  IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController,
  TAbortStrategy, TAdvancedAbortSignalWrapPromiseOptions, TCatchAbortedCallback
} from '../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';
import { TGenericAdvancedAbortControllerLike } from '../../../advanced-abort-controller/advanced-abort-controller-types';
import { NormalizeAdvancedAbortSignalWrapPromiseOptionsOnAbortedController } from './normalize-advanced-abort-signal-wrap-promise-options-on-aborted-controller';
import { IsObject } from '@lifaon/traits';
import { NormalizeAdvancedAbortSignalWrapPromiseOptionsStrategy } from './normalize-advanced-abort-signal-wrap-promise-options-strategy';
import { NormalizeAdvancedAbortSignalWrapPromiseOptionsOnAborted } from './normalize-advanced-abort-signal-wrap-promise-options-on-aborted';

export interface IAdvancedAbortSignalWrapPromiseNormalizedOptions<GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>{
  strategy: GStrategy;
  onAborted?: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController>;
  onAbortedController?: GAdvancedAbortController;
}

export function NormalizeAdvancedAbortSignalWrapPromiseOptions<GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
  options: TAdvancedAbortSignalWrapPromiseOptions<GStrategy, GAborted, GAdvancedAbortController> = {} as any
): IAdvancedAbortSignalWrapPromiseNormalizedOptions<GStrategy, GAborted, GAdvancedAbortController> {
  if (IsObject(options)) {
    const strategy: GStrategy = NormalizeAdvancedAbortSignalWrapPromiseOptionsStrategy<GStrategy>(options.strategy);
    const onAborted: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController> | undefined = NormalizeAdvancedAbortSignalWrapPromiseOptionsOnAborted<GStrategy, GAborted, GAdvancedAbortController>((options as any).onAborted);
    const onAbortedController: GAdvancedAbortController | undefined = NormalizeAdvancedAbortSignalWrapPromiseOptionsOnAbortedController<GStrategy, GAborted, GAdvancedAbortController>(onAborted, (options as any).onAbortedController);
    return {
      ...options,
      strategy,
      onAborted,
      onAbortedController
    };
  } else {
    throw new TypeError(`Expected object or void as options`);
  }
}
