import {
  TAbortStrategy, TCatchAbortedCallback
} from '../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';
import { TGenericAdvancedAbortControllerLike } from '../../../advanced-abort-controller/advanced-abort-controller-types';

export function NormalizeAdvancedAbortSignalWrapPromiseOptionsOnAborted<GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
  onAborted?: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController>,
  defaultValue: TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController> | undefined = void 0
): TCatchAbortedCallback<GAborted, GStrategy, GAdvancedAbortController> | undefined {
  if (onAborted === void 0) {
    return defaultValue;
  } else if (typeof onAborted === 'function') {
    return onAborted;
  } else {
    throw new TypeError(`Expected function or void as onAborted`);
  }
}
