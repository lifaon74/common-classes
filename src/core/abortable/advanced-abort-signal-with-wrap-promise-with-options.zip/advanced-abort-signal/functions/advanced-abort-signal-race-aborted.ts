import { EventListenerOnWithAsyncUnsubscribe, TraitEventListenerOn } from '@lifaon/traits';
import { TAdvancedAbortSignalKeyValueTupleUnion } from '../advanced-abort-signal-types';
import { TraitAdvancedAbortSignalIsAborted } from '../traits/trait-advanced-abort-signal-is-aborted';
import { TEventListenerOnUnsubscribeAsync } from '@lifaon/traits/src/build-in-traits/event-listener/trait-event-listener-on/event-listener-on-with-async-unsubscribe';
import { TraitEventListenerIsDispatching } from '@lifaon/traits/src/build-in-traits/event-listener/trait-event-listener-is-dispatching/trait-event-listener-is-dispatching';


export interface IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal extends TraitEventListenerOn<any, TAdvancedAbortSignalKeyValueTupleUnion>, TraitAdvancedAbortSignalIsAborted<any>, TraitEventListenerIsDispatching<any> {

}

/**
 * Returns a Promise resolving as soon as 'promise' is resolved or 'advancedAbortSignal' is aborted
 */
export function AdvancedAbortSignalRaceAborted<GValue>(
  advancedAbortSignal: IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal,
  promise: PromiseLike<GValue>,
): Promise<GValue | void> {
  let unsubscribe: TEventListenerOnUnsubscribeAsync;
  return Promise.race([
    new Promise<void>((resolve: any) => {
      if (advancedAbortSignal.isAborted()) {
        resolve();
      } else {
        unsubscribe = EventListenerOnWithAsyncUnsubscribe<TAdvancedAbortSignalKeyValueTupleUnion, 'abort'>(
          advancedAbortSignal,
          'abort',
          () => {
            resolve();
          }
        );
      }
    }),
    promise
  ])
    .finally(() => {
      if (unsubscribe !== void 0) {
        unsubscribe();
      }
    });
}
