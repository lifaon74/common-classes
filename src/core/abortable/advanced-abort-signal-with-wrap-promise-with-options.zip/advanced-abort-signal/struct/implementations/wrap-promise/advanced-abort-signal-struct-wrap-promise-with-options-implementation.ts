import { TGenericAdvancedAbortSignalStruct } from '../../advanced-abort-signal-struct';
import { Impl } from '@lifaon/traits';
import { TraitAdvancedAbortSignalWrapPromiseWithOptions } from '../../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options';
import { TAdvancedAbortSignalWrapPromiseArgument } from '../../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-types';
import {
  IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController,
  IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndWithoutOnAbortedController,
  IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted, TAbortStrategy, TAdvancedAbortSignalWrapPromiseOptions,
  TInferAbortStrategyReturnedPromise
} from '../../../traits/wrap-promise/trait-advanced-abort-signal-wrap-promise-with-options-types';
import { TGenericAdvancedAbortControllerLike } from '../../../../advanced-abort-controller/advanced-abort-controller-types';
import { IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal } from '../../../functions/advanced-abort-signal-race-aborted';

export interface ImplTraitWrapPromiseForAdvancedAbortSignalStructGSelfConstraint extends TGenericAdvancedAbortSignalStruct, IAdvancedAbortSignalRaceAbortedAdvancedAbortSignal {

}

@Impl()
export class ImplTraitWrapPromiseForAdvancedAbortSignalStruct<GSelf extends ImplTraitWrapPromiseForAdvancedAbortSignalStructGSelfConstraint> extends TraitAdvancedAbortSignalWrapPromiseWithOptions<GSelf> {
  wrapPromise<GValue>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
  ): TInferAbortStrategyReturnedPromise<GValue, 'never', never>;

  wrapPromise<GValue, GStrategy extends TAbortStrategy>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options: IAdvancedAbortSignalWrapPromiseOptionsWithoutOnAborted<GStrategy>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, never>;

  wrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options: IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndWithoutOnAbortedController<GStrategy, GAborted>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted>;

  wrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options: IAdvancedAbortSignalWrapPromiseOptionsWithOnAbortedAndOnAbortedController<GStrategy, GAborted, GAdvancedAbortController>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted>;

  wrapPromise<GValue, GStrategy extends TAbortStrategy, GAborted, GAdvancedAbortController extends TGenericAdvancedAbortControllerLike>(
    this: GSelf,
    promiseOrCallback: TAdvancedAbortSignalWrapPromiseArgument<GValue>,
    options?: TAdvancedAbortSignalWrapPromiseOptions<GStrategy, GAborted, GAdvancedAbortController>,
  ): TInferAbortStrategyReturnedPromise<GValue, GStrategy, GAborted> {
    throw 'TODO';
  }
}
